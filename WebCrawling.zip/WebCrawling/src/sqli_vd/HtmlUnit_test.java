/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqli_vd;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import java.lang.reflect.Field;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

/**
 *
 * @author Dell
 */
public class HtmlUnit_test {
    
    private static Object get(Object object, String field) throws Exception 
    {
            Field f = object.getClass().getDeclaredField(field);
            f.setAccessible(true);
            return f.get(object);
    }

    
    public static void main(String[] args) throws Exception 
    {
         HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.CHROME);
        driver.get("http://localhost/finalresult/loginf.php");
        
        System.out.println("this tis the title of the page:=> "+driver.getTitle());
        
        WebClient webClient = (WebClient) get(driver, "webClient");
        System.out.println("web client version "+webClient.getBrowserVersion());
        
        System.out.println("is it CHROME? ");
        System.out.println(webClient.getBrowserVersion().isChrome());
        System.out.println(webClient.getBrowserVersion().isFirefox());
        
         
        
        driver.quit();
    }
    
}
