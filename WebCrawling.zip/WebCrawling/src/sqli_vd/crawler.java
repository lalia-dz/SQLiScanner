/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqli_vd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author Dell
 */
public class crawler {

     public static final int sleepInterval = 1000; // interval between getting pages for webserver friendliness :)

    List<String> allowedUrls;
    List<String> seedUrls;
    List<String> foundAndVisitedUrls;
    List<String> foundLinks;
    List<String> deadLinks;

    public crawler() {
        allowedUrls = new ArrayList<String>();
        seedUrls = new ArrayList<String>();
        foundAndVisitedUrls = new ArrayList<String>();
        deadLinks = new ArrayList<String>();
        foundLinks = new ArrayList<String>();

        allowedUrls.add("http://www.simplesite.com/");
        seedUrls.add("http://www.simplesite.com/");

        //http://www.simplesite.com/
        foundLinks.addAll(seedUrls);
    }

    public void run() {
        
            while(!(foundLinks.isEmpty())){
            String pageToCrawl = foundLinks.get(0);
            log("Crawling " + pageToCrawl);
            crawl(pageToCrawl);}
        

        log("\n\nreporting found urls:");
        for(String s : foundAndVisitedUrls) {
            log(s);
        }
    }

    private Document getDoc(String url) {
        try { 
         Document doc = Jsoup.connect(url).get(); 
            return doc;
        } catch (IOException e) { 
            System.out.println("Adding URL: " + url + " to list of dead links");
            deadLinks.add(url);
        }

        return null;
    }

    private String[] getLinksFromDocument(Document doc) {
      
        Elements elements = doc.select("a");
        String[] links = new String[elements.size()];

        Iterator i = elements.iterator();
        int b = 0;

        while(i.hasNext()) {
            links[b] = ((Element) i.next()).attr("abs:href");
            b++;
        }

        return links;
    
    }// FIN getLinksFromDocument

    private void crawl(String url) {
        if(!urlAllowed(url)) return;

        Document page = getDoc(url);
         System.out.println("A");
if(page!=null){ 
        String[] links = getLinksFromDocument(page);

        for(String l : links) {
            if(urlAllowed(l)) {
             //   System.out.println("A");
                if(!foundLinks.contains(l)) {
                    foundLinks.add(l);
                }
                // System.out.println("B");
            }
        }
}
        foundLinks.remove(url);
        foundAndVisitedUrls.add(url);
    
    }

    private boolean urlAllowed(String url) {

        boolean allowed = false;

        //stay within certain domains
        for(String u : allowedUrls) {
             if(url.startsWith(u)) allowed = true;
        }

        //make sure we havent already found that the links is dead
        for(String u : deadLinks) {
            if(url.equals(u)) allowed = false;
        }

        //make sure we havent already visited it
        for(String u : foundAndVisitedUrls) {
            if(url.equals(u)) allowed = false;
        }

        return allowed;

    }

    private void log(String item) {
        System.out.println(item);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
