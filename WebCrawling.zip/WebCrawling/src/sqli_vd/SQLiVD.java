/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqli_vd;

import java.lang.*;
import com.gargoylesoftware.htmlunit.CollectingAlertHandler;
import com.gargoylesoftware.htmlunit.CookieManager;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.PromptHandler;
import com.gargoylesoftware.htmlunit.ScriptException;
import com.gargoylesoftware.htmlunit.SilentCssErrorHandler;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.html.HtmlHiddenInput;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlPasswordInput;
import com.gargoylesoftware.htmlunit.html.HtmlSubmitInput;
import com.gargoylesoftware.htmlunit.html.HtmlTextInput;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptErrorListener;
import com.google.common.io.Files;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.FormElement;
import org.jsoup.select.Elements;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
//import static sqli_vd.Test_12.BB;

/**
 *
 * @author Dell
 */
public class SQLiVD extends javax.swing.JFrame {

    public void Demo()
    {
        JLabel background;
        setSize(1200,700);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        ImageIcon img = new ImageIcon("C:\\Users\\Dell\\Desktop\\Discoveries.AAA");
        background = new JLabel("", img, JLabel.CENTER);
        background.setBounds(0,0,1200,700);
        add(background);
        setVisible(true);
    }
    
   
    
     public static Connection con=null;
     public static DBconnect db=null;
     public static Statement statement = null;
     public static ResultSet resultSet = null,resultSet2 = null;
     public static PreparedStatement preparedStatement = null,preparedStatement1 = null,preparedStatement2 = null,preparedStatement3 = null, ps=null;
     //public static String site;
     
      public static final int sleepInterval = 1000;
     
    List<String> allowedUrls;
    List<String> seedUrls;
    List<String> foundAndVisitedUrls;
    List<String> foundLinks;
    List<String> deadLinks;
     
    static double user_sim;
    
    
    
    
    List<String> alertsMessages=new ArrayList<String>();
            List<String> promptMessages=new ArrayList<String>();
    
    
    
    
    
    /////////////////// url-listes /////////
    List<String> liste_inject_url=new ArrayList<>();  
              List<String> list_path_part=new ArrayList<>(); 
               List<String> liste_parms_part=new ArrayList<>(); 
                List<String> list_key_part=new ArrayList<>(); 
                  List<String> list_value_part=new ArrayList<>(); 
                    //List<String> liste_url5=new ArrayList<String>(); 
                      //List<String> liste_url6=new ArrayList<String>();
                      
                      List<Parameter_url> list_ALLParts=new ArrayList<>();
                      
                      List<String> payloads_url = new ArrayList<>();
                      
                      List<String> List_payload =new ArrayList<>();
                      
                      List<String> list_found_search=new ArrayList<>();
                                    
                      
                      
                      
                      String malicious_page ;
                      List<String>split_payload = new ArrayList();
                      List<String> error_sheet =new ArrayList<>();
                      List<String> email_sheet = new ArrayList<>();
                      List<String> password_sheet = new ArrayList<>();
                      List<String> txt_sheet = new ArrayList<>();
                      List<String> Authen_sheet = new ArrayList<>();
                      List<String> all_sheet =new ArrayList<>();
                      List<String> blind_true_sheet =new ArrayList<>();
                      List<String> blind_false_sheet =new ArrayList<>();
                      List<String> Error_based_sheet =new ArrayList<>();
                       List<String> URL_sheet =new ArrayList<>();
                     // List<String> x_BF =new ArrayList<>();
                     // List<String> x_BT =new ArrayList<>();
                     // List<String> x_EB =new ArrayList<>();
                      
File file = new File("error_wordList\\sheet.txt"); 
File file2 = new File("error_wordList\\errors.txt");
//File file3 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\Other\\email_sheet.txt"); 
File file4 = new File("error_wordList\\Authentication_sheet.txt");
//File file5 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\Other\\text_sheet.txt");
//File file6 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\Other\\password_sheet.txt"); 
File file7 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\Blind_string_true.txt"); 
File file8 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\Blind_string_false.txt"); 
File file9 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\Error_based_sheet.txt"); 
File file10 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\x_BF.txt"); 
File file11 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\x_BT.txt"); 
File file12 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\x_EB.txt"); 
File file13 = new File("C:\\Users\\Anes\\Documents\\NetBeansProjects\\WebCrawling\\error_wordList\\URL_sheet.txt"); 


  
                      
                      
    public SQLiVD() {
        initComponents();
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Dell\\Desktop\\Discoveries\\1_sRNSrCiXfGju3nCNX8PKAA.jpeg")); // NOI18N
        jLabel3.setText("jLabel3");

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sqli_vd/AAA.jpeg"))); // NOI18N
        jLabel5.setText("jLabel5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setForeground(java.awt.Color.lightGray);
        getContentPane().setLayout(null);

        jButton2.setBackground(new java.awt.Color(204, 204, 204));
        jButton2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 0));
        jButton2.setText("Crawling");
        jButton2.setPreferredSize(new java.awt.Dimension(80, 32));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(750, 20, 152, 46);

        jTextField1.setText("Example: www.site.com");
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField1FocusGained(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(213, 14, 511, 51);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Enter a Website URL");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 20, 200, 51);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(220, 140, 660, 260);

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton1.setText("Scann");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(20, 340, 152, 47);

        jCheckBox1.setBackground(new java.awt.Color(0, 0, 102));
        jCheckBox1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jCheckBox1.setForeground(new java.awt.Color(255, 255, 255));
        jCheckBox1.setText("inject in URL");
        getContentPane().add(jCheckBox1);
        jCheckBox1.setBounds(27, 159, 116, 24);

        jCheckBox2.setBackground(new java.awt.Color(0, 0, 102));
        jCheckBox2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jCheckBox2.setForeground(new java.awt.Color(255, 255, 255));
        jCheckBox2.setText("inject in inputs");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox2);
        jCheckBox2.setBounds(27, 215, 132, 24);

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Select Your Scan");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(27, 105, 150, 24);

        jButton3.setBackground(new java.awt.Color(204, 204, 204));
        jButton3.setForeground(new java.awt.Color(0, 0, 0));
        jButton3.setText("clear data");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(220, 400, 150, 50);

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("choose Similarity % = ");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(10, 270, 150, 30);

        jTextField2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField2);
        jTextField2.setBounds(160, 270, 40, 30);

        jButton5.setBackground(new java.awt.Color(204, 204, 204));
        jButton5.setForeground(new java.awt.Color(0, 0, 0));
        jButton5.setText("Creat Report");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(370, 400, 160, 50);

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Records");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(220, 100, 170, 40);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sqli_vd/AAA.jpeg"))); // NOI18N
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(0, 0, 920, 620);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         long startTime = System.nanoTime();
        int id_site = 0,id_url = 0,id_form;
        String site=jTextField1.getText();
        //String  url;
        
        try{
            if(db==null)  {db=new DBconnect(); con=db.gettConnection() ;}
            
            //site=jTextField1.getText();
            
            String sql="INSERT INTO websites (site) SELECT ? FROM DUAL WHERE NOT EXISTS  (SELECT * FROM websites WHERE site=?)";
            preparedStatement = con.prepareStatement(sql);
            
            preparedStatement.setString(1, site);
            preparedStatement.setString(2, site);
            
            preparedStatement.executeUpdate();
            
            String sql2="SELECT id_site,site from websites where site =? ;";
            preparedStatement = con.prepareStatement(sql2);
            preparedStatement.setString(1, site);
            
            resultSet = preparedStatement.executeQuery();
            id_site=get_id_site(resultSet);
            //print_int(id_site);
            System.out.println("----id side: "+id_site);
            
            //extract urls
            allowedUrls = new ArrayList<>();
            seedUrls = new ArrayList<>();
            foundAndVisitedUrls = new ArrayList<>();
            deadLinks = new ArrayList<>();
            foundLinks = new ArrayList<>();
            
            
            allowedUrls.add(site);
            seedUrls.add(site);
            foundLinks.addAll(seedUrls);
            
            //crawling
            while(!(foundLinks.isEmpty()))
            {   
                //System.out.println("SSSSSSSSSS");
                String pageToCrawl = foundLinks.get(0);
                System.out.println("--------------new strat-------------");
                System.out.println("pageToCrawl: "+pageToCrawl);
                
                if((!pageToCrawl.contains("pdf")) || (!pageToCrawl.contains("png")) || (!pageToCrawl.contains("gif")) || (!pageToCrawl.contains("#")) || (!pageToCrawl.contains("jpg")) || (!pageToCrawl.contains("txt")) || (!pageToCrawl.contains("zip")) || (!pageToCrawl.contains("rar")))
                {
                    crawling(pageToCrawl);
                    System.out.println("RRRRRRRRRRRRS");
                    //fill url links in urls table
                    String sql3="INSERT INTO urls (url,id_site) SELECT ?,? FROM DUAL WHERE NOT EXISTS  (SELECT * FROM urls WHERE url=? and id_site=?)";
                    preparedStatement = con.prepareStatement(sql3);
                    preparedStatement.setString(1, pageToCrawl);
                    preparedStatement.setInt(2, id_site);
                    preparedStatement.setString(3, pageToCrawl);
                    preparedStatement.setInt(4, id_site);
                    
                    preparedStatement.executeUpdate();
                    
                    
                    
                    //get inputs 
                    String sql4="SELECT * from urls where id_site =? and url=? ;";
                    PreparedStatement preparedStatementURL = con.prepareStatement(sql4);
                    
                    preparedStatementURL.setInt(1, id_site);
                    preparedStatementURL.setString(2, pageToCrawl);
                    ResultSet resultSetURL = preparedStatementURL.executeQuery();
                    
                    //get id url
                    while(resultSetURL.next())
                    {
                    id_url=resultSetURL.getInt("id_url");
                    }
                    
                    
                    try {
                       // List<String> List_formid =new ArrayList<String>(); 
                        //System.out.println("this is the url doing error**********"+pageToCrawl);
                        Document doc1 = Jsoup.connect(pageToCrawl).userAgent("Mozilla").referrer("http://www.google.com").timeout(1000*5).ignoreContentType(true).get();
                        
                        //if (doc1.location().contains("http://localhost/dvwa/vulnerabilities/sqli/"))//http://localhost/dvwa/vulnerabilities/sqli/      //http://localhost/finalresult
                        //{
                        Elements  form1 = doc1.select("form");
                        
                    for ( FormElement form3: form1.forms()) 
                    {
                         System.out.println("form of pagetocrawl: "+pageToCrawl);
                         
                         Element form2=form3;
                         String id=form2.attr("id");
                         String action=form2.attr("action");
                         String method=form2.attr("method");
                         
                         String sql5 = "INSERT INTO forms (action,method,id,id_url) SELECT ?,?,?,? ";
                         preparedStatement1 = con.prepareStatement(sql5);
                         preparedStatement1.setString(1, action);
                         preparedStatement1.setString(2, method);
                         preparedStatement1.setString(3, id);
                         preparedStatement1.setInt(4, id_url);
                         
                         preparedStatement1.executeUpdate();
                         
                         String sql6 = "SELECT * from forms where id =? ";
                         preparedStatement2 = con.prepareStatement(sql6);
                         
                         preparedStatement2.setString(1, form2.attr("id"));
                         resultSet2 = preparedStatement2.executeQuery();
                         
                         id_form=get_id_form(resultSet2);
                         System.out.println("----idform: "+id_form);
                         
                         Elements data= form3.elements();
                         if(!data.isEmpty())
                         {
                             System.out.println("table found");
                         
                             for (Element input : data)
                             {
                                System.out.println("input found");System.out.println(input);
                                Elements inputt=input.select("input,select,textarea");
                                 
                                //System.out.println("id_form in input boucle"+id_form);
                                
                                
                                
                                String button="button";
                                Elements buttons = input.select(button);System.out.println("buttons= "+buttons);
                                if(!buttons.isEmpty())
                                {
                                    System.out.println("here@@@@@@@@@@");
                                    String b_class =buttons.attr("class");
                                    String b_type = buttons.attr("type");
                                    String b_name = buttons.attr("name");
                                    String b_sql="INSERT INTO inputs (type,name,class,id_form) SELECT ?,?,?,? FROM DUAL WHERE NOT EXISTS  (SELECT * FROM inputs WHERE name=? and id_form=? and type=?)";
                                    preparedStatement3 = con.prepareStatement(b_sql);
                                    preparedStatement3.setString(1,b_type);
                                    preparedStatement3.setString(2,b_name);
                                    preparedStatement3.setString(3, b_class);
                                    preparedStatement3.setInt(4, id_form);
                                    preparedStatement3.setString(5, b_name);
                                    preparedStatement3.setInt(6, id_form);
                                    preparedStatement3.setString(7,b_type);
                                    preparedStatement3.executeUpdate();
                                }else{
                                
                                String sql8="INSERT INTO inputs (type,name,value,class,id_form) SELECT ?,?,?,?,? FROM DUAL WHERE NOT EXISTS  (SELECT * FROM inputs WHERE name=? and id_form=? and type=?)";
                                preparedStatement3 = con.prepareStatement(sql8);
                                
                                id=inputt.first().attr("id");
                                String type=inputt.attr("type");
                                
                                if (! inputt.select ("textarea").isEmpty()) 
                                type="textarea";
                                String name= inputt.first().attr("name");System.out.println(name);
                                String value= inputt.first().attr("value");System.out.println(value);
                                String classs= inputt.first().attr("class");System.out.println(classs);
                                
                                //preparedStatement3.setString(1, id);                                                          
                                preparedStatement3.setString(1,type);
                                preparedStatement3.setString(2,name);
                                preparedStatement3.setString(3, value);
                                preparedStatement3.setString(4, classs);
                                preparedStatement3.setInt(5, id_form);
                                preparedStatement3.setString(6, name);
                                preparedStatement3.setInt(7, id_form);
                                preparedStatement3.setString(8,type);
                                preparedStatement3.executeUpdate();}
                             
                             }
                             
                                String sql7="SELECT count(*) as count from inputs where id_form = ? and type not in (?,?)  ";
                                PreparedStatement preparedStatement_input = con.prepareStatement(sql7);
                                preparedStatement_input.setInt(1, id_form);
                                preparedStatement_input.setString(2, "hidden");
                                preparedStatement_input.setString(3, "submit");
                                ResultSet resultSet_input = preparedStatement_input.executeQuery();
                                
                                int count_input = 0;
                                
                                while (resultSet_input.next()) {
                                count_input =resultSet_input.getInt("count");
                                }System.out.println("count-inputs"+count_input);
                         } else
                             for (Element input : form2.select("input,select,textarea")) 
                             {
                                 System.out.println("id_form in input boucle"+id_form);
                                 String sql9="INSERT INTO inputs (id,type,name,value,class,id_form) SELECT ?,?,?,?,?,? FROM DUAL WHERE NOT EXISTS  (SELECT * FROM inputs WHERE name=? and id_form=? and type=?)";
                                 preparedStatement3 = con.prepareStatement(sql9);
                                 System.out.println("##################### input.attr:id= "+input.attr("id"));
                                 id=input.attr("id");
                                String type=input.attr("type");
                                String name= input.attr("name");
                                String value= input.attr("value");
                                String classs= input.attr("class");
                                
                                preparedStatement3.setString(1, id);                                                                       /* and id_form=?*/
                                preparedStatement3.setString(2,type);
                                preparedStatement3.setString(3,name);
                                preparedStatement3.setString(4, value);
                                preparedStatement3.setString(5, classs);
                                preparedStatement3.setInt(6, id_form);
                                preparedStatement3.setString(7, name);
                                preparedStatement3.setInt(8, id_form);
                                preparedStatement3.setString(9,type);
                                preparedStatement3.executeUpdate();
                             }
                         
                         
                    }
                        /*}else
                     throw new IOException("Redirected to wrong domain " + doc1.location());
                    } 
                        catch (IOException ex) {
                                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);} */
                    
                    
                    /*ch (NullPointerException e) {
                    e.printStackTrace();}
                    catch (java.net.UnknownHostException e) {
                        System.out.println("Unknown Host url");
                    }*/
                    
                    
                    } catch (IOException ex) {
                                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (NullPointerException e) {
                    
                        e.printStackTrace();}
                    
                }
                else
                {
                    foundLinks.remove(pageToCrawl);
                }

                
            }
            
            
            
            
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
        }
         /*catch (IOException ex) {
         Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);}*/
        /*catch (IOException ex) {
             Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);}*/
        
         
            JOptionPane.showMessageDialog(null, "The Crawling done !");
            long endTime   = System.nanoTime();
            long totalTime = endTime - startTime;
            long second =totalTime / 1_000_000_000;
            System.out.println(second);
            long convert = TimeUnit.SECONDS.convert(totalTime, TimeUnit.NANOSECONDS);
             System.out.println(convert);
            
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        long startTime = System.nanoTime();
        String text = jTextField2.getText();
        double user;
        if(!text.isEmpty())
        {
            user = Integer.parseInt(jTextField2.getText());System.out.println("user_sim"+user);
            if(user > 100 || user<1) JOptionPane.showMessageDialog(null, "please enter similarity between (0-100)");
            else user_sim = user/100; System.out.println("user/100= "  +user_sim);
        }   
        else user_sim = 1;
        
        
         try { 
             //BufferedReader br = new BufferedReader(new FileReader(file));//sheet.txt
             BufferedReader br2 = new BufferedReader(new FileReader(file2)); //error.txt
            //BufferedReader br3 = new BufferedReader(new FileReader(file3)); // email_sheet.txt
            BufferedReader br4 = new BufferedReader(new FileReader(file4));   //Authentication_sheet.txt
//            BufferedReader br5 = new BufferedReader(new FileReader(file5)); // text_sheet.txt
            //BufferedReader br6 = new BufferedReader(new FileReader(file6)); // password_sheet.txt
            BufferedReader br7 = new BufferedReader(new FileReader(file7)); // blind_true
            BufferedReader br8 = new BufferedReader(new FileReader(file8));// blind false
            BufferedReader br9 = new BufferedReader(new FileReader(file9)); // error_based
            //BufferedReader br10 = new BufferedReader(new FileReader(file10));// x_BF
            //BufferedReader br11 = new BufferedReader(new FileReader(file11));// x_BT
            //BufferedReader br12 = new BufferedReader(new FileReader(file12));//x_EB
            BufferedReader br13 = new BufferedReader(new FileReader(file13));//URL_sheet
            
            
            String st;
            
           /* while ((st = br.readLine()) != null )
            {
                all_sheet.add(st);
            }*/
            
             while ((st = br2.readLine()) != null )
            {
                error_sheet.add(st);
            }
             /*while ((st = br3.readLine()) != null )
            {
                email_sheet.add(st);
            }*/
            
             while ((st = br4.readLine()) != null )
            {
                Authen_sheet.add(st);
            }
//             while ((st = br5.readLine()) != null )
            {
                txt_sheet.add(st);
            }
            
              /*while ((st = br6.readLine()) != null )
            {
                password_sheet.add(st);
            }*/
             
             while ((st = br7.readLine()) != null )
            {
                blind_true_sheet.add(st);
            }
            
              while ((st = br8.readLine()) != null )
            {
                blind_false_sheet.add(st);
            }
            
              while ((st = br9.readLine()) != null )
            {
                Error_based_sheet.add(st);
            }
            /*  while ((st = br10.readLine()) != null )
            {
                x_BF.add(st);
            }
              while ((st = br11.readLine()) != null )
            {
                x_BT.add(st);
            }
              while ((st = br12.readLine()) != null )
            {
                x_EB.add(st);
            }*/
              while ((st = br13.readLine()) != null )
            {
                URL_sheet.add(st);
            }
              
         } catch (FileNotFoundException ex) {
             Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
         } catch (IOException ex) {
             Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
         }
       
             
        if(jCheckBox1.isSelected() && !jCheckBox2.isSelected())
        {
            try {
                injection_by_url();
            } catch (SQLException | IOException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(jCheckBox2.isSelected() && !jCheckBox1.isSelected())
        {      
            injection_by_input();
        
        }//end of select inject_input button  
        
        if(jCheckBox1.isSelected() && jCheckBox2.isSelected())
        {
             try {
                 injection_by_url();
             } catch (SQLException ex) {
                 Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
             } catch (IOException ex) {
                 Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
             }
            injection_by_input();
        }
        
        JOptionPane.showMessageDialog(null, "The scanning done..... !");
        long endTime   = System.nanoTime();
        long totalTime = endTime - startTime;
        //long seconds = TimeUnit.NANOSECONDS.toSeconds(after - before);
        long convert = TimeUnit.SECONDS.convert(totalTime, TimeUnit.NANOSECONDS);
        System.out.println(convert);
        
    }//GEN-LAST:event_jButton1ActionPerformed
    void injection_by_input()
    {
        try {
              if(db==null)  try {
                  db=new DBconnect(); con=db.gettConnection() ;
              } catch (ClassNotFoundException ex) {
                  Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
              }
          
             ResultSet 
             resultSet_inj_submit = null,
             resultSet_inj_id_url=null,
             resultSet_inj_url=null,
             resultSet_inj_input=null;
             
             PreparedStatement 
             ps_inj_submit = null,
             ps_inj_id_url=null,
             ps_inj_url=null,
             ps_inj_input=null;
            
             // select input type "submit" 
             String sql_sub ="SELECT * from inputs where type =? ";
             ps_inj_submit  = con.prepareStatement(sql_sub);
             ps_inj_submit.setString(1, "submit");
             resultSet_inj_submit = ps_inj_submit.executeQuery();
             int count =0;
             list_found_search.add("init");
            while (resultSet_inj_submit.next()) 
        {   count++;
            System.out.println("||||||||||||Submit("+count+")||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                
            String submit_name = resultSet_inj_submit.getString("name");
            String submit_value = resultSet_inj_submit.getString("value");
            int id_form = resultSet_inj_submit.getInt("id_form");
    
            String method = null;
            String id_of_form =null ;//id_of_form is the id_parameter from the 'form'      
            int id_url = 0 ;
            String url =null; 
    
            
            List<String> textField=new ArrayList<>();
            List<String> passwordField=new ArrayList<>();
            List<String> emailField=new ArrayList<>(); 
            List<String> hiddenField=new ArrayList<>(); 
            List<String> textareaField=new ArrayList<>();
            List<String> numberField=new ArrayList<>();
      
            // select form => input => submit
            String sql_subForm ="SELECT * from forms where id_form =? ";
            ps_inj_id_url  = con.prepareStatement(sql_subForm);
            ps_inj_id_url.setInt(1, id_form);
            resultSet_inj_id_url = ps_inj_id_url.executeQuery();
                 
            while (resultSet_inj_id_url.next()) 
                 { 
                     id_url = resultSet_inj_id_url.getInt("id_url"); 
                     method=resultSet_inj_id_url.getString("method"); 
                     id_of_form =resultSet_inj_id_url.getString("id");           
                 }
                 
                 ///////////////////////////////////not useful 'yet' //////////////////////////
            // count all input but 'hidden and submit'
            String sql_subInput = "SELECT count(*) as count from inputs where id_form = ? and type not in (?,?)";
            PreparedStatement preparedStatement_input = con.prepareStatement(sql_subInput);
            preparedStatement_input.setInt(1, id_form);
            preparedStatement_input.setString(2, "hidden");
            preparedStatement_input.setString(3, "submit");
            
            ResultSet resultSet_input = preparedStatement_input.executeQuery();
            
            int count_input = 0;
            while (resultSet_input.next()) 
            {
                      count_input =resultSet_input.getInt("count");
            }
           
            
            //select url => form => input => submit
            
            String sql_subUrl = "SELECT * from urls where id_url =?";
            ps_inj_url  = con.prepareStatement(sql_subUrl);
            ps_inj_url.setInt(1, id_url);
            resultSet_inj_url = ps_inj_url.executeQuery();
                          
            while (resultSet_inj_url.next()) 
            { 
                url = resultSet_inj_url.getString("url");              
            }
                       
            //  get iput type 'textfileds' => form 
            //System.out.println("id_form eeeeeeeeeeeeeeeee"+id_form);
            String sql_textfieled = "SELECT * from inputs where id_form =? and (type in (?) or type in (?))";
            ps_inj_input  = con.prepareStatement(sql_textfieled);               
            ps_inj_input.setInt(1,id_form);
            ps_inj_input.setString(2,"texte");
            ps_inj_input.setString(3,"text");
            
            resultSet_inj_input = ps_inj_input.executeQuery();
                          
             while (resultSet_inj_input.next()) 
             { 
                textField.add(resultSet_inj_input.getString("name")); System.out.println(textField);
             }
             
            // get iput type 'password' => form
            
            String sql_password = "SELECT * from inputs where id_form =? and type=?;"; 
            ps_inj_input  = con.prepareStatement(sql_password);
            ps_inj_input.setInt(1,id_form);
            ps_inj_input.setString(2,"password");
                          
            resultSet_inj_input = ps_inj_input.executeQuery();
            
            while (resultSet_inj_input.next()) 
            { 
                passwordField.add(resultSet_inj_input.getString("name")); 
            }   
            
            //get iput type 'email' => form
            
            String sql_email = "SELECT * from inputs where id_form =? and type=?";
            ps_inj_input  = con.prepareStatement(sql_email);
            ps_inj_input.setInt(1,id_form);
            ps_inj_input.setString(2,"email");
                          
            resultSet_inj_input = ps_inj_input.executeQuery();
            while (resultSet_inj_input.next()) 
            { 
                emailField.add(resultSet_inj_input.getString("name")); 
            }  
            
            /*
            //get input type 'hidden' => form
            
            String sql_hidden = "SELECT * from inputs where id_form =? and type=?;";
            ps_inj_input  = con.prepareStatement(sql_hidden);
            ps_inj_input.setInt(1,id_form);
            ps_inj_input.setString(2,"hidden");
                          
            resultSet_inj_input = ps_inj_input.executeQuery();
            
            while (resultSet_inj_input.next()) 
            { 
                hiddenField.add(resultSet_inj_input.getString("name")); 
            }   
            */
            /////////////////////////// not useful 'yet' //////////////////
            //get input type 'textarea' => form
            
            String sqm_textarea = "SELECT * from inputs where id_form =? and type=?;";
            ps_inj_input  = con.prepareStatement(sqm_textarea);
            ps_inj_input.setInt(1,id_form);
            ps_inj_input.setString(2,"textarea");
                          
            resultSet_inj_input = ps_inj_input.executeQuery();
            
            while (resultSet_inj_input.next()) 
            { 
                textareaField.add(resultSet_inj_input.getString("name")); 
            }   
                
                
         
            
         ///////////////////////////////HtmlUnit///////////////////////   
            try (final WebClient webClient = new WebClient()) 
            {
                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
                 webClient.getOptions().setThrowExceptionOnScriptError(false);
            webClient.getOptions().setJavaScriptEnabled(false);
//            webClient.setCssErrorHandler(new SilentCssErrorHandler());
                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
    java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);

                
                webClient.getOptions().setJavaScriptEnabled(true);
                webClient.getOptions().setThrowExceptionOnScriptError(false);
   
                
                final HtmlPage page = webClient.getPage(url);
                
                HtmlForm form = null;
                
                 if(!id_of_form.isEmpty())
                 {
                    form = page.getHtmlElementById(id_of_form);
                    
                    if((count_input > 0))
                    { 
                    //1//System.out.println("id_form found: start injecting form ");
                    injection_one_input(url, submit_name, submit_value, page, form, textField, passwordField, hiddenField, emailField, textareaField, count_input); 

                    }
                 }else
                 {
                     System.out.println("id_form is empty: start finding form...  ");
                     List<HtmlForm> list_forms=page.getForms();
                     
                     for(int i=0;i<list_forms.size();i++)
                     {
                         form = page.getForms().get(i);
                         String form_xml = form.asXml();
                         String s="value=\""+submit_value+"\"";
                         String s1="name=\""+submit_name+"\"";
                         
                         if(form_xml.contains(s) || form_xml.contains(s1) || list_forms.size()==1)
                         {
                             if((count_input > 0))
                             {
                                System.out.println("id_form found!");
                                injection_one_input(url,submit_name,submit_value,page,form,textField,passwordField,hiddenField,emailField, textareaField, count_input); 
                             }
                            
                         }
                         
                     }
                     
                 }
                
                
                
            }   catch (IOException | FailingHttpStatusCodeException | ParserConfigurationException | SAXException ex) {  
                    Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                }  
            
            
        }//end loop for each submit
                } catch (SQLException ex) {
             Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
             System.out.println("-----------end injection ALL inputs!----------!");
         }
    }
    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        
        if(db==null)  {try {
            db=new DBconnect(); con=db.gettConnection() ;
            
            
           preparedStatement = con.prepareStatement("delete from inputs");
            preparedStatement.executeUpdate();
            
            preparedStatement = con.prepareStatement("delete from forms");
            preparedStatement.executeUpdate();
            
            preparedStatement = con.prepareStatement("delete from urls");
            preparedStatement.executeUpdate();
           
            preparedStatement = con.prepareStatement("delete from websites");
            preparedStatement.executeUpdate();
            
            
            } catch (SQLException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            }
}
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTextField1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1FocusGained
    
    
    void injection_one_input(String url,String submit_name,String submit_value,HtmlPage page1,HtmlForm form,List<String> textField,List<String> passwordField,List<String> hiddenField,List<String> emailField,List<String> textareaField, int count_input) throws FileNotFoundException, IOException, ParserConfigurationException, SAXException
    {
        
        List<HtmlTextInput> text_Field=new ArrayList<>();  
        List<HtmlPasswordInput> password_Field=new ArrayList<>(); 
        List<HtmlInput> email_Field = new ArrayList<>();
        List<HtmlHiddenInput> hidden_Field=new ArrayList<>();
         List<HtmlHiddenInput> textarea_Field=new ArrayList<>();
        
        
        
        HtmlSubmitInput button=null;   
        HtmlTextInput text_H=null; 
        HtmlHiddenInput textarea_H=null; 
        HtmlPasswordInput pass_H=null; 
        HtmlHiddenInput hidd_H=null;
        HtmlInput email_H=null;
                                                                    System.out.print("count inputs= "+count_input);
        
        /*if(!(textareaField.isEmpty()))
         for(int i=0;i<textareaField.size();i++)
         {                                                         //System.out.println("input_name= "+textField.get(i)+" "+url);
             textarea_H = form.getInputByName(textareaField.get(i));
             textarea_Field.add(textarea_H);
                                                                   
         }//end loop textfield        */
         
         if(!(textField.isEmpty()))
         for(int i=0;i<textField.size();i++)
         {                                                         //System.out.println("input_name= "+textField.get(i)+" "+url);
             text_H = form.getInputByName(textField.get(i));
             text_Field.add(text_H);
                                                                   
         }//end loop textfield                          
                                                 System.out.println(submit_value+"    textfield: "+text_Field.size());
         if(!(passwordField.isEmpty()))
          for(int i=0;i<passwordField.size();i++)
          {
              pass_H =form.getInputByName(passwordField.get(i));
              password_Field.add(pass_H);
          } //end loop passwordfield
                                                 System.out.println(submit_value+"    passwordfield: "+passwordField.size());
         if(!(hiddenField.isEmpty()))
          for(int i=0;i<hiddenField.size();i++)
          { 
              hidd_H =form.getInputByName(hiddenField.get(i));
              hidden_Field.add(hidd_H);
          }//end loop hiddenField
                                                System.out.println(submit_value+"    hiddenfield: "+hiddenField.size());
         if(!(emailField.isEmpty()))
          for(int i=0;i<emailField.size();i++)
          { 
              email_H =form.getInputByName(emailField.get(i));
              email_Field.add(email_H);
          }//end loop emailField
                                                System.out.println(submit_value+"  emailField: "+emailField.size()+" count input:("+count_input+")");System.out.println("");
         /*if(!(submit_name.isEmpty()))   
                button =form.getInputByName(submit_name);  
          else if (!submit_value.isEmpty()) 
                button =form.getInputByValue(submit_value);*/
          //else 
               button = (HtmlSubmitInput) page1.getByXPath("//input[@type='submit']").get(0);   // for automating submit button what ever the type=> (<input type='submit> OR <button type='submit')
          
         
          String payload, input;
          //System.out.println("URL= @@@@  "+url+ " @@@@");
          // inject login-form
          if(  text_Field.size() == 1  && password_Field.size() == 1 && count_input == 2)
          {
              			
			
	      boolean vul =false;
              int q=0;
              System.out.println("------------------------------injecting into login with username authentication:---------------------");
              String pageAsXml,pageAsXml2, pageAsXml3;
              double sim1,sim2;
              HtmlPage page;
              input = textField.get(0);
              System.out.println("---injecting (susername) user Authentication:");
            for (String List_payload1 : Error_based_sheet) 
            {
		if(vul == false)
		{
                                                                                q++;
                payload = List_payload1; 
                text_Field.get(0).setValueAttribute(payload);
                password_Field.get(0).setValueAttribute(random_method("AS"));
                //input = textField.get(0);
                
                page = button.click();
                System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                System.out.println("vul= "+vul);
                 if(vul == false)
                 {      //String hohoho = page.asXml();
                     System.out.println("checking(SIM)");
                     pageAsXml = get_Xmlpage_login(url, form, input, random_method("S"), passwordField.get(0), random_method("AS"), button);
                     vul = similarity_based(pageAsXml, url, input, payload);
                 }    
		}else break;   
            }// end injecting username login(1)*/
		vul=false; // just for testing	
		if(vul == false)
                {
                    System.out.println("chekcing for tautology ");
                    for(String List_payload1 : Authen_sheet)
                    {
                        if(vul == false)
                        {
                            payload = List_payload1;
                            System.out.println(""+url+"   "+payload +" input= "+input);
                            text_Field.get(0).setValueAttribute(payload);
                            password_Field.get(0).setValueAttribute(random_method("AS"));
                            page = button.click();//malicious_page = page.asXml();
                            //if(payload.contains("admin' #")) System.out.println(""+page.asXml());
                            pageAsXml = get_Xmlpage_login(url, form, input, random_method("S"), passwordField.get(0), random_method("AS"), button);
                            vul = similarity_based_tautology(pageAsXml, page.asXml(),url, input, payload);
                        
                        }else break;
                        
                    }
                }//end tautology
                vul=false; // just for testing
		if(vul == false)
                {    
                    System.out.println("checking(Blin_B)");
                    for(int sh=0; sh<blind_true_sheet.size(); sh++)
                    {
                        //System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                        pageAsXml2 = get_Xmlpage_login(url, form, input, blind_true_sheet.get(sh), passwordField.get(0), random_method("AS"), button);
                        pageAsXml3 = get_Xmlpage_login(url, form, input, blind_false_sheet.get(sh), passwordField.get(0), random_method("AS"), button);
                        sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                        sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                        if((sim1==1) && (sim2!=1))
                        {
                            vul=true;
                            System.out.println("blind injection found!||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||-");
                            store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                            break;
                        }
                    }
							   
                }// end checking Blind
            
            int qq=0;
            System.out.println("----injecting (password) user Authentication");
            vul = false;
            input = passwordField.get(0);
            for (String List_payload1 : Error_based_sheet) 
            {                                                               
                if(vul == false)
		{                                                                qq++;
                    payload = List_payload1;                                     System.out.println("--next sheet("+qq+")");
                    text_Field.get(0).setValueAttribute(random_method("S"));
                    password_Field.get(0).setValueAttribute(payload);
                    // input = passwordField.get(0);
                
                    page = button.click();
                    System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                    vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                    System.out.println("vul= "+vul);
                    if(vul == false)
                    {
                        System.out.println("checking(SIM)");
                        pageAsXml = get_Xmlpage_login(url, form, input, random_method("S"), passwordField.get(0), random_method("AS"), button);
                        vul = similarity_based(pageAsXml, url, input, payload);
                    
                    }
                }else break;
            }// end injecting username lognin(2)
            vul=false; // just for testing
            if(vul == false)
                {
                    System.out.println("chekcing for tautology "); 
                    for(String List_payload1 : Authen_sheet)
                    {                                   
                        if(vul == false)
                        {
                            payload = List_payload1;
                            password_Field.get(0).setValueAttribute(payload);
                            text_Field.get(0).setValueAttribute(random_method("S"));
                            page = button.click();//malicious_page = page.asXml();
                            pageAsXml = get_Xmlpage_login(url, form, input, random_method("S"), passwordField.get(0), random_method("AS"), button);
                            vul = similarity_based_tautology(pageAsXml, page.asXml(),url, input, payload);
                        
                        }else break;
                        
                    }
                }//end tautology
            vul=false; // just for testing
            if(vul == false)
             {    
                System.out.println("checking(Bli_B)");
                for(int sh=0; sh<blind_true_sheet.size(); sh++)// blind_true_sheet.get(sh)   blind_false_sheet.get(sh)
                {
                     System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                    pageAsXml2 = get_Xmlpage_login(url, form, input, random_method("S"), passwordField.get(0), blind_true_sheet.get(sh), button);
                    pageAsXml3 = get_Xmlpage_login(url, form, input, random_method("S"), passwordField.get(0), blind_false_sheet.get(sh), button);
                    sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                    sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                    if((sim1==1) && (sim2!=1))
                    {
                       // vul=true;
                        System.out.println("blind injection found!|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                        store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                        break;
                    }
                }
             }//end checking blind
            
          }// end injection login with username 
          
          else if ( email_Field.size() == 1 && password_Field.size() == 1 && count_input == 2)
          {
              System.out.println("------------------------------injecting into login wih email authentication------------------------------");
              String pageAsXml,pageAsXml2, pageAsXml3;
              double sim1,sim2;
              HtmlPage page;
              input = emailField.get(0);
              boolean vul=false;
              int qqq= 0;
              System.out.println("----injecting (email) user Authentication");
            for (String List_payload1 : Error_based_sheet) 
            {
                if(vul == false)
                {
                    qqq++;
                    payload = List_payload1;                                        System.out.println("--next sheet("+qqq+")");
                    email_Field.get(0).setValueAttribute(payload);
                    password_Field.get(0).setValueAttribute(random_method("AS"));
                
                
                    page = button.click();
                    System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                    vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                    System.out.println("vul= "+vul);
                    if(vul == false)
                    {
                        System.out.println("checking(SIM)");
                        pageAsXml = get_Xmlpage_login(url, form, input, random_method("email"), passwordField.get(0), random_method("AS"), button);
                        vul= similarity_based(pageAsXml, url, input, payload);
                    }
                 
               }else break;
                
            }// end injection email login part(1)
            if(vul == false)
                {
                    System.out.println("chekcing for tautology ");
                    for(String List_payload1 : Authen_sheet)
                    {
                        if(vul == false)
                        {
                            payload = List_payload1;
                            email_Field.get(0).setValueAttribute(payload);
                            password_Field.get(0).setValueAttribute(random_method("AS"));
                            page = button.click();//malicious_page = page.asXml();
                            pageAsXml = get_Xmlpage_login(url, form, input, random_method("email"), passwordField.get(0), random_method("AS"), button);
                            vul = similarity_based_tautology(pageAsXml, page.asXml(),url, input, payload);
                        
                        }else break;
                        
                    }
                }//end tautology
            if(vul == false)
            {
                System.out.println("checking(BLI_B)");
                for(int sh=0; sh<blind_true_sheet.size(); sh++)
                {
                    System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                    pageAsXml2 = get_Xmlpage_login(url, form, input, blind_true_sheet.get(sh), passwordField.get(0), random_method("AS"), button);
                    pageAsXml3 = get_Xmlpage_login(url, form, input, blind_false_sheet.get(sh), passwordField.get(0), random_method("AS"), button);
                    sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                    sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                    if((sim1==1) && (sim2!=1))
                    {
                        vul=true;
                        System.out.println("blind injection found!||||||||||||||||||||||||||||||||");
                        store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                        break;
                    }
                }
            }// end blind 
            
            int qqqq= 0;
            System.out.println("-----injecting (password) user Authentication");
            vul = false;
            input = passwordField.get(0);
            for (String List_payload1 : Error_based_sheet) 
            {
                if(vul == false)
                {
                     qqqq++;
                    payload = List_payload1;                                        System.out.println("--next sheet("+qqqq+")");
                    email_Field.get(0).setValueAttribute(random_method("email"));
                    password_Field.get(0).setValueAttribute(payload);
                    //input = passwordField.get(0);
                
                    page = button.click();
                    System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                    vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                    System.out.println("vul= "+vul);
                    if(vul == false)
                    {
                        System.out.println("checking(SIM)");
                        pageAsXml = get_Xmlpage_login(url, form, input, random_method("email"), passwordField.get(0), random_method("AS"), button);
                        vul =  similarity_based(pageAsXml, url, input, payload);
                     
                    }
                }else break;                                                                
               
            }// end injection password part
            if(vul == false)
                {
                    System.out.println("chekcing for tautology ");
                    for(String List_payload1 : Authen_sheet)
                    {
                        if(vul == false)
                        {
                            payload = List_payload1;
                            password_Field.get(0).setValueAttribute(payload);
                            email_Field.get(0).setValueAttribute(random_method("email"));
                            page = button.click();//malicious_page = page.asXml();
                            pageAsXml = get_Xmlpage_login(url, form, input, random_method("email"), passwordField.get(0), random_method("AS"), button);
                            vul = similarity_based_tautology(pageAsXml, page.asXml(), url, input, payload);
                        
                        }else break;
                        
                    }
                }//end tautology
            if(vul == false)
            {
                System.out.println("checking(BLI_B)");
                for(int sh=0; sh<blind_true_sheet.size(); sh++)
                {
                    System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                    pageAsXml2 = get_Xmlpage_login(url, form, input, random_method("email"), passwordField.get(0), blind_true_sheet.get(sh), button);
                    pageAsXml3 = get_Xmlpage_login(url, form, input, random_method("email"), passwordField.get(0), blind_false_sheet.get(sh), button);
                    sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                    sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                    if((sim1==1) && (sim2!=1))
                    {
                        vul=true;
                        System.out.println("blind injection found!||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                        store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                        break;
                    }
                }
            }
          }// end injecting login with email
          
          else 
          if(email_Field.size() > 0 )
              {     
                  System.out.println("------------------------------injecting into email fields---------------------");
             
                  boolean vul=false;int q=0;
                  String pageAsXml,pageAsXml2, pageAsXml3;
                  double sim1,sim2;
                  HtmlPage page;
                  for(int t=0; t<email_Field.size(); t++)
                   {
                        input = emailField.get(t);
                        
                       for(int i=0;i<Error_based_sheet.size();i++)
                       {     
                           if(vul == false)
                         {
                           payload = Error_based_sheet.get(i);
                           email_Field.get(t).setValueAttribute(payload);
                           
                           for(int k=0;k<t;k++)email_Field.get(k).setValueAttribute("");  
                           
                           page = button.click();
                           System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                            vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                            System.out.println("vul= "+vul);
                           if(vul == false)
                           {
                               System.out.println("checking(SIM)");
                               pageAsXml = get_Xmlpage(url, form,input, random_method("email"), button);
                               vul= similarity_based(pageAsXml, url, input, payload);
                               
                            }
                          }else break;
                        } 
                       if(vul == false)
                                {
                                    System.out.println("checking(BLI_B)");
                                    for(int sh=0; sh<blind_true_sheet.size(); sh++)
                                    {
                                        System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                                        pageAsXml2 = get_Xmlpage(url, form,input, blind_true_sheet.get(sh), button);
                                        pageAsXml3 = get_Xmlpage(url, form,input, blind_false_sheet.get(sh), button);
                                        sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                                        sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                                        if((sim1==1) && (sim2!=1))
                                        {
                                            vul=true;
                                            System.out.println("blind injection found!||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                                            store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                                            break;
                                        }
                                    }
                                }//end blind
                   }
                  
                  System.out.println("end injecting email fields................................;.......");
                  
                  
              }//end injecting email_Field
                 
              
              else  
              if(!text_Field.isEmpty() )
              {    //System.out.println("hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                  
                  String s_inp = text_Field.get(0).toString().toLowerCase(); 
                  String f = form.toString();
                  String pageAsXml,pageAsXml2, pageAsXml3;
                  HtmlPage page;
                  boolean vul=false;
                  if(text_Field.size() == 1 && (f.toLowerCase().contains("search") ||  f.toLowerCase().contains("searchfor") || f.toLowerCase().contains("find") 
                          || f.toLowerCase().contains("query") || f.toLowerCase().contains("recherche") || s_inp.contains("searchfor") || s_inp.contains("name='q'") 
                          || s_inp.contains("find") || s_inp.contains("query") || s_inp.contains("recherche")))
                  {
                      
                      System.out.println("------------------------------injectin into search field ------------------------------");
                     String s, text;
                     input = textField.get(0);
                      for(int q=0;q<Error_based_sheet.size();q++)
                     {
                         payload = Error_based_sheet.get(q);
                         text_Field.get(0).setValueAttribute(payload);
                         page = button.click();
                         System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                         vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                         if(vul == false)
                           {    //System.out.print("vul= "+vul);System.out.println("inputs= "+input);
                               System.out.println("checking(SIM)");
                                pageAsXml = get_Xmlpage(url, form, input, random_method("S"), button);
                               //text_Field.get(t).setValueAttribute(random_method("S"));System.out.println("this is text node valu= "+text_Field.get(t));
                                //String random_page , String url, String input, String payload
                               vul= similarity_based( pageAsXml, url, input, payload);
                               if(vul = true)
                               {
                                   text=page.asText();
                                   
                                   for(int c=0; c<payload.length(); c++)
                                    {
                                         //split_payload.add(payload.charAt(c));
                                         s= String.valueOf(payload.charAt(c));
                                        if(text.contains(s))
                                        {
                                            //vul=true;
                                            System.out.println("not vul |||||||||||||||||||||||-");
                                        }else 
                                        {
                                            vul = true;
                                            System.out.println("vul in search field");
                                            break;
                                        }
                                    }
                                   
                               }
                           }else break; 
                         
                     }
                      /*Scanner sc5 = new Scanner(System.in);
            String st5 = sc5.next();*/
                      System.out.println("------------------------------------------------------------------------------------------");
                      
                      
                      
                     /* try {
                         
                            preparedStatement1 = con.prepareStatement("insert into search_table (search_url,search_input, search_form, search_vul) SELECT ?,?,?,?");
                            preparedStatement1.setString(1, url);
                            preparedStatement1.setString(2, s_inp);
                            preparedStatement1.setString(3, f);
                            preparedStatement1.setBoolean(4, false);
                            preparedStatement1.executeUpdate();
                            } catch (SQLException ex) {
                                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                            }*/
                      /* boolean found=false;
                      for(int ip=0; ip<list_found_search.size(); ip++)
                      {
                          if((f.equals(list_found_search.get(ip)))) 
                          {
                              list_found_search.add(f); System.out.println("this is a searh field! "+s_inp);
                              found=true;
                          }else{list_found_search.add(f); break;}
                      }
                      if(found == true)
                      {
                          System.out.println("not vulnerable!");
                           try {
                            preparedStatement1 = con.prepareStatement("insert into search_table (search_url,search_input, search_form, search_vul) SELECT ?,?,?,?");
                            preparedStatement1.setString(1, url);
                            preparedStatement1.setString(2, s_inp);
                            preparedStatement1.setString(3, f);
                            preparedStatement1.setBoolean(4, false);
                            preparedStatement1.executeUpdate();
                            } catch (SQLException ex) {
                                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                            }
                          
                      }*/
                      
                  }
                  else if (text_Field.size() == 1 && (! f.toLowerCase().contains("search") ||  ! f.toLowerCase().contains("searchfor") || ! f.toLowerCase().contains("find") 
                          || ! f.toLowerCase().contains("query") || ! f.toLowerCase().contains("recherche") || ! s_inp.contains("searchfor") || ! s_inp.contains("name='q'") 
                          || ! s_inp.contains("find") || ! s_inp.contains("query") || ! s_inp.contains("recherche")) || text_Field.size() >= 1  ){
                  
                      //System.out.println("belowwwwwwwwwwwwwwwwwwwwwww");
                  System.out.println("------------------------------injecting into text fields---------------------");
                      System.out.println("input= "+ s_inp);
                   vul=false; int q=0;
                  double sim1,sim2;
                  
                  System.out.println("injecting text fields...");
                  
                   for(int t=0; t<text_Field.size(); t++)
                   {
                       input = textField.get(t);
                       
                       for(int i=0;i<Error_based_sheet.size();i++)
                       {    
                           if(vul==false)
                          {
                           payload = Error_based_sheet.get(i);
                           text_Field.get(t).setValueAttribute(payload);
                           
                           
                           for(int k=0;k<t;k++)text_Field.get(k).setValueAttribute("");  
                           
                            
                            page = button.click();
                            System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                            vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                            //System.out.println("vul= "+vul);
                           if(vul == false)
                           {    //System.out.print("vul= "+vul);System.out.println("inputs= "+input);
                               System.out.println("checking(SIM)");
                                pageAsXml = get_Xmlpage(url, form, input, random_method("S"), button);
                               //text_Field.get(t).setValueAttribute(random_method("S"));System.out.println("this is text node valu= "+text_Field.get(t));
                                //String random_page , String url, String input, String payload
                               vul= similarity_based( pageAsXml, url, input, payload);
                           }
                           
                          }else break;    
                        }  
                       vul=false; // just for testing
                       if(vul == false)
                               {
                                   System.out.println("checking(BLI_B)");
                                   for(int sh=0; sh<blind_true_sheet.size(); sh++)
                                    {
                                        System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                                        pageAsXml2 = get_Xmlpage(url, form,input, blind_true_sheet.get(sh), button);
                                        pageAsXml3 = get_Xmlpage(url, form,input, blind_false_sheet.get(sh), button);
                                        sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                                        sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                                        if((sim1==1) && (sim2!=1))
                                        {
                                           // vul=true;
                                            System.out.println("blind based found! |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                                            store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                                            break;
                                        }
                                    }
                               }
                   }System.out.println("end injecting into textfield.................................;");
                }//end injecting text_Field
              }  
                  
                  
              
              
              else if(password_Field.size() > 0)
              {   
                  System.out.println("------------------------------injecting into password fields---------------------");
             
                   String pageAsXml,pageAsXml2, pageAsXml3, TagSeq1,TagSeq2;
                   double sim1,sim2;
                   HtmlPage page;
                  boolean vul=false; int q=0;
                  for(int p=0; p<password_Field.size(); p++)
                   {
                      input = passwordField.get(p);
                       for(int i=0;i<Error_based_sheet.size();i++)
                       {
                         if(vul==false)
                         {
                           payload = Error_based_sheet.get(i);
                           password_Field.get(p).setValueAttribute(payload);
                           
                           
                           for(int k=0;k<p;k++)password_Field.get(k).setValueAttribute("");
                           
                            page = button.click();
                            System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                            vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                            System.out.println("vul= "+vul);
                           if(vul == false)
                            {   
                                System.out.println("checking(SIM)");
                                pageAsXml = get_Xmlpage(url, form,input, random_method("AS"), button);
                                vul = similarity_based(pageAsXml, url, input, payload);
                                
                            }
                            }else break;
                        }
                       vul=false; // just for testing
                       if(vul == false)
                                {   
                                    System.out.println("checking(BLI_B)");
                                    for(int sh=0; sh<blind_true_sheet.size(); sh++)
                                    {
                                        System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                                        pageAsXml2 = get_Xmlpage(url,form, input, blind_true_sheet.get(sh), button);
                                        pageAsXml3 = get_Xmlpage(url,form, input, blind_false_sheet.get(sh), button);
                                        sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                                        sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                                        if((sim1==1) && (sim2!=1) )
                                        {
                                            vul=true;
                                            System.out.println("blind based found! |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                                            store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                                            break;
                                        }
                                    }
                                }
                       
                   }System.out.println("end injection into passwordfield ...................................................");
              }// end injecting password_Field
          //////////////////////////////////////////////////
          else if(textarea_Field.size() > 0)
              {   
                  System.out.println("------------------------------injecting into textarea fields---------------------");
             
                   String pageAsXml,pageAsXml2, pageAsXml3, TagSeq1,TagSeq2;
                   double sim1,sim2;
                   HtmlPage page;
                  boolean vul=false; int q=0;
                  for(int p=0; p<textarea_Field.size(); p++)
                   {
                      input = textareaField.get(p);
                       for(int i=0;i<Error_based_sheet.size();i++)
                       {
                         if(vul==false)
                         {
                           payload = Error_based_sheet.get(i);
                           textarea_Field.get(p).setValueAttribute(payload);
                           
                           
                           for(int k=0;k<p;k++)textarea_Field.get(k).setValueAttribute("");
                           
                            page = button.click();
                            System.out.print("checking(ERR_B)");System.out.println("    "+url+"  payload= "+payload+"input= "+input);
                            vul = check_error_based( url, page, payload,  Error_based_sheet , error_sheet , input);
                            System.out.println("vul= "+vul);
                           if(vul == false)
                            {   
                                System.out.println("checking(SIM)");
                                pageAsXml = get_Xmlpage(url, form,input, random_method("AS"), button);
                                vul = similarity_based(pageAsXml, url, input, payload);
                                
                            }
                          }else break;
                       }
                       if(vul == false)
                                {   
                                    System.out.println("checking(BLI_B)");
                                    for(int sh=0; sh<blind_true_sheet.size(); sh++)
                                    {
                                        System.out.println(""+url+"   "+blind_true_sheet.get(sh) +"input= "+input);
                                        pageAsXml2 = get_Xmlpage(url,form, input, blind_true_sheet.get(sh), button);
                                        pageAsXml3 = get_Xmlpage(url,form, input, blind_false_sheet.get(sh), button);
                                        sim1 = sim(TagSequense(pageAsXml2), TagSequense(page1.asXml()));
                                        sim2 = sim(TagSequense(pageAsXml3), TagSequense(page1.asXml()));
                                        if((sim1==1) && (sim2!=1) )
                                        {
                                            vul=true;
                                            System.out.println("blind based found! |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                                            store_blind_based(url, input, blind_false_sheet.get(sh), vul);
                                            break;
                                        }
                                    }
                                }
                       
                   }System.out.println("end injection into textareafield ...................................................");
              }// end injecting textarea
              
          
    }// end injecting inputs
   
///////////////////////////////////////////////////////::
    /////////////////////////////////////////////////
    //////////////////////////////////////////////////
    
    static void store_blind_based(String url, String input, String payload, boolean vul)
    {
        try {
                preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, input_vul, payload_vul, blind_based) SELECT ?,?,?,?");
                 preparedStatement1.setString(1, url);
                         preparedStatement1.setString(2, input);
                         preparedStatement1.setString(3, payload);
                         preparedStatement1.setBoolean(4, vul);
                preparedStatement1.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    static String random_method(String random) 
	{        
            switch(random){
                case "S":
                    int leftLimit = 97; // letter 'a'
                    int rightLimit = 122; // letter 'z'
                    int targetStringLength = 10;
                    Random r = new Random();
                    StringBuilder buffer = new StringBuilder(targetStringLength);
                    for (int i = 0; i < targetStringLength; i++) {
                    int randomLimitedInt = leftLimit + (int) 
                    (r.nextFloat() * (rightLimit - leftLimit + 1));
                    buffer.append((char) randomLimitedInt);
                    }
                    String generatedString = buffer.toString();
                    return generatedString;
                    
                    case"AS":
                        int n =15;
                        byte[] array = new byte[256]; 
                        new Random().nextBytes(array); 
                        String randomString = new String(array, Charset.forName("UTF-8")); 
                        StringBuilder build = new StringBuilder(); 
                        String AlphaNumericString = randomString.replaceAll("[^A-Za-z0-9]", ""); 
                        for (int k = 0; k < AlphaNumericString.length(); k++) { 
			if (Character.isLetter(AlphaNumericString.charAt(k)) && (n > 0) 
				|| Character.isDigit(AlphaNumericString.charAt(k)) && (n > 0)) { 
				build.append(AlphaNumericString.charAt(k)); 
				n--; 
			} }     
                        return build.toString();
                    
                    case "email":
                        int n1 =15;
                        byte[] array1 = new byte[256]; 
                        new Random().nextBytes(array1); 
                        String randomString1 = new String(array1, Charset.forName("UTF-8")); 
                        StringBuilder build1 = new StringBuilder(); 
                        String AlphaNumericString1 = randomString1.replaceAll("[^A-Za-z0-9]", ""); 
                        for (int k = 0; k < AlphaNumericString1.length(); k++) { 
			if (Character.isLetter(AlphaNumericString1.charAt(k)) && (n1 > 0) 
				|| Character.isDigit(AlphaNumericString1.charAt(k)) && (n1 > 0)) { 
				build1.append(AlphaNumericString1.charAt(k)); 
				n1--; 
			} }     
                        String email = build1.toString()+"@gmail.com";
                        return email;
                    default:
                        return "defaultString";
            }
            
	} 
    static String TagSequense(String Xmlpage) throws ParserConfigurationException, SAXException, IOException
    {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder dbuild = dbf.newDocumentBuilder();
            org.w3c.dom.Document docu = dbuild.parse(new InputSource(new StringReader(Xmlpage)));
            
            docu.getDocumentElement().normalize();
            org.w3c.dom.NodeList nodeList = docu.getElementsByTagName("*");
            
            List<String> A = new ArrayList<>();   
            for (int i=0; i<nodeList.getLength(); i++) 
            {
                org.w3c.dom.Node node = nodeList.item(i);
                 A.add(node.getNodeName());
            }
            
        return A.toString();
    }
     public String get_Xmlpage_login(String url, HtmlForm form, String first_input,String first_random ,String password_input,String password_random, HtmlSubmitInput button) throws IOException, ParserConfigurationException, SAXException
    {
        
     String RP_xml;
        try (final WebClient webClient = new WebClient()) {
            java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
            java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
            webClient.getOptions().setThrowExceptionOnScriptError(false);
            webClient.getOptions().setJavaScriptEnabled(false);
            
            
        //final HtmlPage page = webClient.getPage(url);
        
            /*HtmlInput inputusername = page.getElementByName(first_input);
            HtmlPasswordInput inputpassword = page.getElementByName(password_input);//login_password*/
            //HtmlSubmitInput Button = page.getFirstByXPath("//input[@value='"+button+"']");//Sign in
            
            HtmlInput username = form.getInputByName(first_input);
            HtmlPasswordInput password = form.getInputByName(password_input);//login_password*/
            
        
            username.setValueAttribute(first_random);
            password.setValueAttribute(password_random);
            //HtmlPage RPage = Button.click();
            HtmlPage RPage = button.click();
             RP_xml = RPage.asXml();
            
            }
        
        return(RP_xml);
    }
     public String get_Xmlpage(String url,HtmlForm form, String inputname,String random, HtmlSubmitInput button) throws IOException
     {
            String RP_xml;
        try (final WebClient webClient = new WebClient()) {
            java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
            java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
            webClient.getOptions().setThrowExceptionOnScriptError(false);
            webClient.getOptions().setJavaScriptEnabled(false);
            
            
        //final HtmlPage page = webClient.getPage(url);
        
                //System.out.println("url:: "+url);
                //System.out.println("page== "+page.asXml());
            
            //HtmlForm Form = page.getHtmlElementById(form);
            HtmlInput input_name = form.getInputByName(inputname);
            input_name.setValueAttribute(random);
            
            //HtmlSubmitInput Button = page.getFirstByXPath("//input[@value='Go']");//Sign in
            HtmlPage RPage = button.click();
            //HtmlPage RPage = button.click();
            RP_xml = RPage.asXml();
            //System.out.println(RP_xml);System.out.println("----------------------------------------------------------------------------------------------------------------------");
        } 
        return(RP_xml);
     }
     
     public double sim(String p1, String p2)
     {
         double lcs = longestCommonsubsequenceLength2(p1, p2);
        double Dp1 = p1.length();
        double Dp2 = p2.length();
        double similarity = (2* lcs) / (Dp1+Dp2);
        return similarity;
     }

    boolean check_error_based(String url,HtmlPage page ,String payload, List<String> List_payload,List<String> List_error ,String input) throws IOException
    {
            boolean vul = false;
            
            String RP_tostring =  page.asText(); //System.out.println(RP_tostring);
             //String response_page = page.asXml();
             //String RP_tostring= response_page.toString();  //System.out.println(payload);
             malicious_page = page.asXml();//System.out.println("######{");System.out.println(malicious_page);System.out.println("######}");
             
              URL obj = new URL(url);
              HttpURLConnection connec = (HttpURLConnection) obj.openConnection();
              int responseCode = connec.getResponseCode();
              
              if(responseCode == 500)
              {
                  vul=true;
                  System.out.println("Error based vulnerablility found!");
                  System.out.println("url: "+url+"   input= "+input);
                  try {
                        preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, input_vul, payload_vul, status_code) SELECT ?,?,?,?");
                         preparedStatement1.setString(1, url);
                         preparedStatement1.setString(2, input);
                         preparedStatement1.setString(3, payload);
                         preparedStatement1.setInt(4, responseCode);
                        preparedStatement1.executeUpdate();
                    } catch (SQLException ex) {
                    Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                    }
              }else
              {
                  for (String error : List_error) {
                        //System.out.println("error= "+error);
                    if (RP_tostring.contains(error)) 
                    {
                        vul = true;
                        System.out.println("Error based vulnerablility found!||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                        System.out.println("url: "+url+"   input= "+input+"   payload: "+payload+" of_error: " + error);
                        
                        try {
                            preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, input_vul, payload_vul, error_based) SELECT ?,?,?,?");
                            preparedStatement1.setString(1, url);
                            preparedStatement1.setString(2, input);
                            preparedStatement1.setString(3, payload);
                            preparedStatement1.setString(4, error);
                            preparedStatement1.executeUpdate();
                        } catch (SQLException ex) {
                            Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        break;
                    }
                }
              }
              
             return vul;         
         
    }
    public int longestCommonsubsequenceLength2(String s1, String s2) {

    
    int cache[][] = new int[s2.length() + 1][s1.length() + 1];

   
    for (int s2Row = 0; s2Row <= s2.length(); s2Row++) {
      for (int s1Col = 0; s1Col <= s1.length(); s1Col++) {

        if (s2Row == 0 || s1Col == 0) {

          cache[s2Row][s1Col] = 0;

        } else if (s2.charAt(s2Row - 1) == s1.charAt(s1Col - 1)) {

         
          cache[s2Row][s1Col] = cache[s2Row - 1][s1Col - 1] + 1;
        }
        else {

          cache[s2Row][s1Col] = Math.max(cache[s2Row - 1][s1Col], cache[s2Row][s1Col - 1]);

        }

      }
    }

    return cache[s2.length()][s1.length()];
  }
    
     boolean similarity_based_tautology(String random_page , String page, String url, String input, String payload) throws IOException, ParserConfigurationException, SAXException
    {
        boolean vul = false;
        //System.out.println("-------------------iam here---------------------------");
        
        String random_page_tag = TagSequense(random_page);//System.out.println("random "+random_page_tag);
        String malicious_page_tag = TagSequense(page);//System.out.println("malicious "+malicious_page_tag);
        //System.out.println(random_page_tag);System.out.println(malicious_page_tag);
        double lcs = longestCommonsubsequenceLength2(random_page_tag, malicious_page_tag);
        double Dp1 = random_page_tag.length();
        double Dp2 = malicious_page_tag.length();
        double similarity = (2* lcs) / (Dp1+Dp2);
        double rate = (int) (similarity * 10000);
        rate = rate / 100;
        //System.out.println("similarity= "+similarity);
            if(similarity < 1 && (page.toLowerCase().contains("logout") || page.toLowerCase().contains("log out") || page.toLowerCase().contains("log_out") || page.toLowerCase().contains("sign out") || page.toLowerCase().contains("sign_out")) )
            {
                vul = true;
                System.out.println("tautology based vulnerability found!/|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||--");
                System.out.println("sim= "+rate+"%"+"    url: "+url+"   input= "+input+"   payload: "+payload);
                
            try {
                preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, input_vul, payload_vul, similarity, tautology_based) SELECT ?,?,?,?,?");
                 preparedStatement1.setString(1, url);
                         preparedStatement1.setString(2, input);
                         preparedStatement1.setString(3, payload);
                         preparedStatement1.setDouble(4, rate);
                          preparedStatement1.setBoolean(5, vul);
                        preparedStatement1.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            }

           
            }//else System.out.println("sim= "+rate+"%");
            
            return vul;
    }
    boolean similarity_based(String random_page , String url, String input, String payload) throws IOException, ParserConfigurationException, SAXException
    {
        boolean vul = false;
        //System.out.println("-------------------iam here---------------------------");
        
        String random_page_tag = TagSequense(random_page);//System.out.println("random "+random_page_tag);
        String malicious_page_tag = TagSequense(malicious_page);//System.out.println("malicious "+malicious_page_tag);
        double lcs = longestCommonsubsequenceLength2(random_page_tag, malicious_page_tag);
        double Dp1 = random_page_tag.length();
        double Dp2 = malicious_page_tag.length();
        double similarity = (2* lcs) / (Dp1+Dp2);
        double rate = (int) (similarity * 10000);
        rate = rate / 100;
            if(similarity < user_sim)
            {
                vul = true;
                System.out.println("similarity based vulnerability found!/|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||--");
                System.out.println("sim= "+rate+"%"+"    url: "+url+"   input= "+input+"   payload: "+payload);
                
            try {
                preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, input_vul, payload_vul, similarity) SELECT ?,?,?,?");
                 preparedStatement1.setString(1, url);
                         preparedStatement1.setString(2, input);
                         preparedStatement1.setString(3, payload);
                         preparedStatement1.setDouble(4, rate);
                        preparedStatement1.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            }

           
            }//else System.out.println("sim= "+rate+"%");
            
            return vul;
    }
    
    void injection_by_url() throws SQLException, MalformedURLException, IOException 
    {
        if(db==null)  try {
            db=new DBconnect(); con=db.gettConnection() ;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String[] part1 ;
        String[] part2 ;
        String[] part3 ;
        String[] part4 ;
        
        String sql1="SELECT * from urls where url LIKE '%?%'";
        PreparedStatement ps_inject_url = con.prepareStatement(sql1);
        ResultSet result_inject_url = ps_inject_url.executeQuery();
        
        String url;
        while(result_inject_url.next())
        {
            url=result_inject_url.getString("url");
            liste_inject_url.add(url);
        }
        
        
        for(int i=0;i<liste_inject_url.size();i++)
        {
            part1 = liste_inject_url.get(i).split("\\?");
            System.out.println("url: "+ liste_inject_url.get(i));
            if(part1.length > 1){
            list_path_part.add(URLDecoder.decode(part1[0], "UTF-8"));
            liste_parms_part.add(URLDecoder.decode(part1[1], "UTF-8"));
            }
        }
        
        part1=null;
        
        for(int i=0;i<liste_parms_part.size();i++)
        {   
            
             part3 = liste_parms_part.get(i).split("&");
            
            if(part3.length >= 1)
            {
                for(int j=0;j<part3.length;j++)
                {
                    part2 = part3[j].split("=");
                    list_key_part.add(part2[0]);
                    //String k = liste_key_part);
                    //System.out.print("---"+liste_key_part);
                    list_value_part.add(part2[1]);
                    //System.out.println("  ---"+liste_value_part);
                    //if(!alreadyexist(liste_url1.get(i),liste_url3))//// don't forget to check this one later
                     //{
                      
                     //}
                }
                Parameter_url p=new Parameter_url(list_path_part.get(i),list_key_part, list_value_part);
                list_ALLParts.add(p);
                list_key_part.clear();
                list_value_part.clear();
            }
            
        }
         
        //for(int i=0;i<list_ALLParts.size();i++)
        //{
            
             /*try (final WebClient webClient = new WebClient()) 
             
              { //WebClient
                    webClient.getOptions().setJavaScriptEnabled(true);
                    webClient.getOptions().setThrowExceptionOnScriptError(false);*/
                    
                    
                    injection_one_url(list_ALLParts);
                    
                    
                    
             /*  }catch (FailingHttpStatusCodeException ex) {
                      Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                  }*/
                
         
        //}
    
    }
    
    private void injection_one_url(List<Parameter_url> par)
    {
       
        try {   
       //System.out.println(" START Injection_with_fitnes_url"+par.par);
        try(final WebClient webClient = new WebClient()) 
             
              { webClient.getOptions().setJavaScriptEnabled(true);
                webClient.getOptions().setThrowExceptionOnScriptError(false); 
//                webClient.setCssErrorHandler(new SilentCssErrorHandler());
                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
    java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);

        
    System.out.println("-------------------injecting URL with (Value + payload)-------------------------------------------");
        int count = 0;
        for(int i=0;i<list_ALLParts.size();i++)//
            {
                count ++;
            System.out.println("----------------injecting the next url ("+count+") ------------------------------------------------------------------------");
           
                boolean vul=false;
                String url,link2,link3,true_xml,false_xml;
                HtmlPage page,page_p,page_r,page_true,page_false;
                double sim1,sim2;
                for(int j=0;j<list_ALLParts.get(i).p_list_key.size();j++)//liste keys
                {
                     url = list_ALLParts.get(i).p_url_part+"?"+list_ALLParts.get(i).p_list_key.get(j)+"="+list_ALLParts.get(i).p_list_value.get(j);
                    System.out.println("url = " +url); 
                    
                    // without modify url value
                    for (String payload : URL_sheet) //list payload
                    {   
                        if(vul == false)
                        {
                             link2 = url+payload; //System.out.println("url_p= "+link2);
                            // link2 = URLDecoder.
                             page_p = webClient.getPage(link2);
                             System.out.print("cheking (EB)");System.out.println("  "+url+"   payload= "+payload);
                             vul = check_error_based_url(url, link2, page_p, payload,error_sheet);
                             System.out.println("here...");
                            if(vul == false)
                            {
                                System.out.println("checking (sim)");
                                link3= url+random_method("AS");
                                page_r = webClient.getPage(link3);
                                vul = similarity_based_url(page_p, page_r, url, payload);
                            }
                            
                            
                        }//else break;
                        
                    }//end 
                    vul = false; // only for testing
                    if(vul == false)
                    {
                        System.out.println("checking(Blin_B)");
                        for(int sh=0; sh<blind_true_sheet.size(); sh++)
                        {
                            System.out.println(url+"   Blind_sheet: "+blind_true_sheet.get(sh) );
                            page= webClient.getPage(url);
                            page_true = webClient.getPage(url+blind_true_sheet.get(sh));
                            page_false = webClient.getPage(url+blind_false_sheet.get(sh));
                            sim1 = sim(TagSequense(page_true.asXml()), TagSequense(page.asXml()));
                            sim2 = sim(TagSequense(page_false.asXml()), TagSequense(page.asXml()));
                            //System.out.println(url+blind_false_sheet.get(sh));
                            System.out.println("sim1= "+sim1+"    sim2= "+sim2);
                            if((sim1==1) && (sim2!=1))
                            {
                                vul=true;
                                System.out.println("blind injection found! ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                                store_blind_based_url(url, blind_false_sheet.get(sh), vul);
                                break;
                            }
                            
                        }
                    }// end blind
                    
                    
                }// end 
                        
            }//end all inj_url
        
        
            // xith (no) value
                  System.out.println("-------------------injecting URL with (NO Value + payload)-------------------------------------------)");
        /*int counting = 0;
        for(int i=0;i<list_ALLParts.size();i++)//
            {
                count ++;
            System.out.println("----------------injecting the next url ("+counting+") ------------------------------------------------------------------------");
           
                boolean vul=false;
                String url,url2,link2,link3,true_xml,false_xml;
                HtmlPage page,page_p,page_r,page_true,page_false;
                double sim1,sim2;
                for(int j=0;j<list_ALLParts.get(i).p_list_key.size();j++)//liste keys
                {
                    url = list_ALLParts.get(i).p_url_part+"?"+list_ALLParts.get(i).p_list_key.get(j)+"=";
                    url2 = list_ALLParts.get(i).p_url_part+"?"+list_ALLParts.get(i).p_list_key.get(j)+"="+list_ALLParts.get(i).p_list_value.get(j);
                    System.out.println("url = " +url); 
                    
                    
                    for (String payload : URL_sheet) //list payload
                    {   
                        if(vul == false)
                        {
                             link2 = url+payload; //System.out.println("url_p= "+link2);
                            // link2 = URLDecoder.
                             page_p = webClient.getPage(link2);
                             System.out.print("cheking (EB)");System.out.println("  "+url+"   payload= "+payload);
                             vul = check_error_based_url(url, link2, page_p, payload,error_sheet);
                            if(vul == false)
                            {
                                System.out.println("checking (sim)");
                                link3= url+random_method("AS");
                                page_r = webClient.getPage(link3);
                                vul = similarity_based_url(page_p, page_r, url, payload);
                            }
                            
                            
                        }else break;
                        
                    }//end 
 /////////////////////////////////// not sure for the next test of no values in key parameters (ambiguity in similarity)
                     vul = false; // only for testing
                    if(vul == false)
                    {
                        System.out.println("checking(Blin_B)");
                        for(int sh=0; sh<blind_true_sheet.size(); sh++)
                        {
                            System.out.println(url+"   Blind_sheet: "+blind_true_sheet.get(sh) );
                            page= webClient.getPage(url2);
                            page_true = webClient.getPage(url+blind_true_sheet.get(sh));
                            page_false = webClient.getPage(url+blind_false_sheet.get(sh));
                            sim1 = sim(TagSequense(page_true.asXml()), TagSequense(page.asXml()));
                            sim2 = sim(TagSequense(page_false.asXml()), TagSequense(page.asXml()));
                            //System.out.println(url+blind_false_sheet.get(sh));
                            System.out.println("sim1= "+sim1+"    sim2= "+sim2);
                            if((sim1==1) && (sim2!=1))
                            {
                               // vul=true;
                                System.out.println("blind injection found! ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                                store_blind_based_url(url, blind_false_sheet.get(sh), vul);
                                //break;
                            }
                            
                        }
                    }// end blind 
   ///////////////////////////////// not sure for the next test of no values in key parameters (ambiguity in similarity)                 
                    
                }// end 
                        
            }//end all inj_url*/
    }
        } catch (Exception e) {
        }
    }
    
    void store_blind_based_url(String url, String payload, boolean vul)
    {
        try {
                preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, payload_vul, blind_based) SELECT ?,?,?");
                 preparedStatement1.setString(1, url);
                         preparedStatement1.setString(2, payload);
                         preparedStatement1.setBoolean(3, vul);
                preparedStatement1.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    boolean similarity_based_url(HtmlPage page_p, HtmlPage page_r, String url, String payload) throws IOException, ParserConfigurationException, SAXException
    {
        boolean vul = false;
        String random_page_tag = TagSequense(page_r.asXml());//System.out.println("random "+random_page_tag);
        String malicious_page_tag = TagSequense(page_p.asXml());//System.out.println("malicious "+malicious_page_tag);
        double lcs = longestCommonsubsequenceLength2(random_page_tag, malicious_page_tag);
        double Dp1 = random_page_tag.length();
        double Dp2 = random_page_tag.length();
        double similarity = (2* lcs) / (Dp1+Dp2);
        double rate = (int) (similarity * 10000);
        rate = rate / 100;
            if(similarity < user_sim)
            {
                vul = true;
                System.out.println("similarity based vulnerability found!/|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||--");
                System.out.println("sim= "+rate+"%"+"    url: "+url+"   payload: "+payload);
                
            try {
                preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, payload_vul, similarity) SELECT ?,?,?");
                 preparedStatement1.setString(1, url);
                         preparedStatement1.setString(2, payload);
                         preparedStatement1.setDouble(3, rate);
                        preparedStatement1.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
            }

           
            }//else System.out.println("sim= "+rate+"%");
            
            return vul;
    }
    
     boolean check_error_based_url(String url,String urlp,HtmlPage page ,String payload, List<String> List_error ) throws IOException
    {
            boolean vul = false;
            //System.out.println("iam here-------------------------");
              URL obj = new URL(urlp);
              HttpURLConnection connec = (HttpURLConnection) obj.openConnection();
              System.out.println("C1....");
              int responseCode = connec.getResponseCode();
              System.out.println("res= "+responseCode);
              System.out.println("also here .....");
              if(responseCode == 500)
              {
                  vul=true;
                  System.out.println("Error based vulnerablility found!response code (500) ");
                  System.out.println("url: "+url);
                  try {
                        preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, payload_vul, status_code) SELECT ?,?,?");
                         preparedStatement1.setString(1, url);
                         preparedStatement1.setString(2, payload);
                         preparedStatement1.setInt(3, responseCode);
                        preparedStatement1.executeUpdate();
                    } catch (SQLException ex) {
                    Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                    }
              }else
              { System.out.println("hiiiiiiiiiiiiiiiiiiiiiiii");
                  for (String error : List_error) 
                {
                      //System.out.println("error==  "+error);
                    if (page.asText().contains(error)) 
                    {
                        vul = true;
                        System.out.println("Error based vulnerablility found!||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
                        System.out.println("url: "+url+"   "+ "payload: "+payload+" of_error: " + error);
                        
                        try {
                            preparedStatement1 = con.prepareStatement("insert into vulnerability (url_vul, payload_vul, error_based) SELECT ?,?,?");
                            preparedStatement1.setString(1, url);
                            preparedStatement1.setString(2, payload);
                            preparedStatement1.setString(3, error);
                            preparedStatement1.executeUpdate();
                        } catch (SQLException ex) {
                            Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        break;
                    }
                }
              }//System.out.println("iam down  "+ vul);
              
             return vul;         
         
    }
    boolean alreadyexist(String par_name, List <String> liste_url3)
    {
        boolean result=false;
        if(par_name.equals(jLabel1))
        {}
        return result;
    }
    private void crawling(String url) 
    {
        if(!isAllowed(url)) return;

        Document page = getDoc(url);
        //System.out.println("geting document........");
        
        if(page!=null)
        {
             //System.out.println("1111111");
             System.out.println("page in not null");
             String[] links = getLinksFromDocument(page);
            if(links != null )
            {
                System.out.println("link is !null");
                for(String l : links) 
                {   
                    l=l.toLowerCase();
                    if(isAllowed(l)) 
                    {   
                        //System.out.println("A");
                        if(!foundLinks.contains(l))
                        {
                            System.out.println("adding: "+l);
                            foundLinks.add(l);
                        }
                
                    }
                }
            }
                //System.out.println("55555");
        }
            System.out.println("666666");
        foundLinks.remove(url);
        //System.out.println("**************");
        foundAndVisitedUrls.add(url);
        System.out.println("end crowling link ------------------");
    
    }
    
   private boolean isAllowed(String url) {
       System.out.println("checking is allowed "+url);
        boolean allowed = false;
        //System.out.println("allowedUrls.size(): "+allowedUrls.size());
        for(int i=0;i< allowedUrls.size();i++) {
            String u=allowedUrls.get(i);
            
            String[] ux=u.split("/");
            String u1,u2;
          /*  if (u1.length>3)u2=u1[2]+"/"+u1[3];
            else*/
             u1=ux[0];
             u2=ux[2];
              // System.out.println("u2:"+u2);
            
             if(url.startsWith(u1+"//"+u2)) {System.out.println("ALLOWED");allowed = true;}
             //if(url.startsWith(u1+"//"+u2 "https://www.hackthissite.org/missions/realistic/4/") ){System.out.println("ALLOWED"); allowed = true;}
        }

        //verifying if url is already found dead
        for(String u : deadLinks) {
            if(url.equals(u)) allowed = false;
        }

        //verifying if url is already visited
        for(String u : foundAndVisitedUrls) {
            if(url.equals(u)) allowed = false;
        }

        return allowed;

    }
   
   
   
   private Document getDoc(String url) {
        try {  System.out.println("geting document...");
            Document doc = Jsoup.connect(url).userAgent("Mozilla").ignoreContentType(true).get();
                //System.out.println("kkkkkkkkkkk");
            return doc;
            
            } catch (IOException e) { System.out.println("00000000000");
            System.out.println("Adding URL: " + url + " to list of dead links");
            deadLinks.add(url);
            }

        return null;
    }
   
    private String[] getLinksFromDocument(Document doc) 
    {   System.out.println("get links of doculment...");
        Elements elements = doc.select("a[href]");
        String[] links = new String[elements.size()];
        //test if ellement != 0 otherwise loop
        /*if(elements.size() == 0)
        {   //System.out.println("emptyyyyyyyyyyyyyyyy");
            return null;
        }
        else*/
        if(elements.size()!= 0)
        {
        System.out.println("size= "+elements.size());
        Iterator <Element> i = elements.iterator();
        
        int b = 0;
        while(i.hasNext()) {
            links[b] =  i.next().attr("abs:href");
            b++;
            }
        }
        //System.out.println("b="+elements.size());
        System.out.println("end get links from document...");return links;
        // System.out.println("erroooooooooooooor---------"+ elements.toString());
        
    }
    
    /*public void print_string(String s)
    {System.out.println("----"+s+"----");}
    public void print_int(int s)
    {System.out.println("----"+s+"----");}*/
    
    
     public int get_id_site(ResultSet resultSet) throws SQLException {
            int id = 0;
            while (resultSet.next()) 
            {
                String id_site = resultSet.getString("id_site");
                id = Integer.parseInt(id_site);
            }
                return id;   }
     
     
      public int get_id_form(ResultSet resultSet) throws SQLException
      {
          int id = 0;
          while (resultSet.next()) 
            {
                String id_form = resultSet.getString("id_form");
                id = Integer.parseInt(id_form);
            }
          return id;
      }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            
            public void run() {
                
                
                new SQLiVD().setVisible(true);
                
                
            }
        });
    }
 
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
