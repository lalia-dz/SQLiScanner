/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqli_vd;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dell
 */
public class Parameter_url {
    
    String p_url_part;
    List <String> p_list_key = new ArrayList<>();
    List <String> p_list_value = new ArrayList<>();
    
    public Parameter_url(String url_part, List <String> list_keys, List <String> list_values)
    {
        p_url_part = url_part;
        
        for(int i=0;i<list_keys.size();i++) 
            p_list_key.add(list_keys.get(i));
        
        for(int j=0;j<list_values.size();j++) 
            p_list_value.add(list_values.get(j));
        
        
    }
}
