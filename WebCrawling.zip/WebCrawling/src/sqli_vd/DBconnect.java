/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqli_vd;

//import Trash.WebCrawler;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Dell
 */
public class DBconnect {
    
    public Connection con=null;  
    
    public DBconnect() throws SQLException, ClassNotFoundException
    {
         try {
             System.out.println("trying to connect to database ...");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/crawlerdb","root","");
            System.out.println("connection Established");
            
         } catch (SQLException ex) {
            Logger.getLogger(SQLiVD.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
    
    public Connection gettConnection() 
         {
             return con;
         }
}
